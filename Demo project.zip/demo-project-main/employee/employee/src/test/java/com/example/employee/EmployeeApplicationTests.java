package com.example.employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}

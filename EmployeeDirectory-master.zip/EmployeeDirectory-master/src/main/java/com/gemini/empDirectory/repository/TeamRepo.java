package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.model.Team;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface TeamRepo extends JpaRepository<Team, Integer> {

    @Query(nativeQuery = true,
    value = "select * from gemini_team where team_name=?1")
    Team findByTeamName(String teamName);

    @Query(nativeQuery = true,
    value = "select team_name from gemini_team")
    Set<String> getAllTeams();

    @Override
    @Query(nativeQuery = true,
            value = "select * from gemini_team")
    List<Team> findAll();
}

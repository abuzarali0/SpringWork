package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.model.EmployeeDirectory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeDirectoryRepo extends JpaRepository<EmployeeDirectory, Integer> {
}

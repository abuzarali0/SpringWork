package com.gemini.empDirectory.model;

import com.gemini.empDirectory.enums.Gender;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "employee_family_details")
public class EmpFamilyDetails {

    @Id
    @Column(name = "family_detail_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(hidden = true)
    private Integer familyDetailId;

    @Column(name = "emp_id")
    @ApiModelProperty(notes = "Employee ID")
    private int empId;

    @Column(name = "relationship")
    @ApiModelProperty(notes = "Relation with Employee")
    private String relationship;

    @Column(name = "name")
    @ApiModelProperty(notes = "Name of Family Member")
    private String name;

    @Column(name = "dob")
    @ApiModelProperty(notes = "Date of Birth of Family Member")
    private LocalDate DOB;

    @Column(name = "gender")
    @ApiModelProperty(value = "Gender of Family Member")
    @Enumerated(EnumType.STRING)
    private Gender gender;

    @Column(name = "occupation")
    @ApiModelProperty(notes = "Occupation of Family Member")
    private String occupation;

    @Column(name = "company")
    @ApiModelProperty(notes = "Company")
    private String company;

    @Column(name = "designation")
    @ApiModelProperty(notes = "Designation")
    private String designation;

    @Column(name = "is_active")
    private boolean isActive = true;

}

package com.gemini.empDirectory.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;


@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "gemini_designation")
public class Designation {
    @Id
    @Column(name = "designation_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(hidden = true)
    private int designationId;

    @Column(name = "designation_name")
    private String designationName;

    public Designation(final String designationName) {
        this.designationName = designationName;
    }
}

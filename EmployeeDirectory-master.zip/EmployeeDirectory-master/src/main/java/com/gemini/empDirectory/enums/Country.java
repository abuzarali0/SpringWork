package com.gemini.empDirectory.enums;

public enum Country {
    INDIA,
    USA
}

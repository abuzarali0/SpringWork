package com.gemini.empDirectory.service;

import com.gemini.empDirectory.StartUpInit;
import com.gemini.empDirectory.dto.*;
import com.gemini.empDirectory.model.Designation;
import com.gemini.empDirectory.model.EmployeeCorpDetails;
import com.gemini.empDirectory.model.Team;
import com.gemini.empDirectory.repository.*;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Slf4j
@Service
@EnableScheduling
public class EmployeeService {

    @Autowired
    private EmployeeRepository empRepository;
    @Autowired
    private DesignationRepo designationRepo;
    @Autowired
    private TeamRepo teamRepo;
    @Autowired
    private EmployeeDirectoryRepo repo;
    @Autowired
    private DepartmentRepo departmentRepo;
    @Autowired
    private StartUpInit startUpInit;
    private List<UserAnniversaryDTO> allWorkAnniversaryList = new ArrayList<>(0);
    private List<BirthdayDTO> allBirthdayList = new ArrayList<>(0);
    private List<NewJoinersDTO> allNewJoinersList = new ArrayList<>(0);

    /**
     * Get all Work Anniversary List
     *
     * @return
     */
    public ResponseApi getAllWorkAnniversaryList() {
        if (allWorkAnniversaryList.size() == 0) {
            return getAnniversaryList();
        } else {
          return new ResponseApi(HttpStatus.OK, allWorkAnniversaryList);
        }
    }

    /**
     * Get all New Joiner List
     *
     * @return
     */

    public List<NewJoinersDTO> getAllNewJoinersList() {
        // If List has no data, just to be sure re-running to fetch exact details.
        if (allNewJoinersList.size() == 0) {
            this.getNewJoinersList();
        }
        return new ArrayList<>(allNewJoinersList);
    }

    /**
     * Get all Birthday List
     *
     * @return
     */
    public ResponseApi getAllBirthdayList() {
        // If List has no data, just to be sure re-running to fetch exact details.
        List<BirthdayDTO> birthdayDTOList;
        if (allBirthdayList.size() == 0) {
            return getBirthdayList();
        } else {
            return new ResponseApi(HttpStatus.OK, allBirthdayList);
        }

    }

    /**
     * @return
     */

    public ResponseApi getPaginatedEmployeeDetails(final Integer pageNumber) {
        try {
            Pageable pageable = PageRequest.of(pageNumber, 10);
            Page<EmployeeCorpDetails> pagedData = empRepository.findAll(pageable);
            return new ResponseApi(HttpStatus.OK, pagedData.toList());
        } catch (Exception e) {
            log.error("Exception in getEmployeeCorpDetails : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to fetch employee details"
            );
        }
    }

    /**
     * @param userId
     * @return
     */

    public ResponseApi getDetailsById(final int userId) {
        try {
            return empRepository
                    .findById(userId)
                    .map(employeeDetails -> new ResponseApi(HttpStatus.OK, employeeDetails))
                    .orElse(
                            new ResponseApi(HttpStatus.BAD_REQUEST, "Employee id does not exist")
                    );
        } catch (Exception e) {
            log.error("Exception in getDetailsById : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to get Employee Details"
            );
        }
    }

    /**
     * @param empId
     * @return
     */

    public ResponseApi deleteEmpDetails(final int empId) {
        try {
            return empRepository
                    .findById(empId)
                    .map(
                            employeeDetails -> {
                                empRepository.delete(employeeDetails);
                                return new ResponseApi(HttpStatus.OK, "Employee Details deleted");
                            }
                    )
                    .orElse(
                            new ResponseApi(HttpStatus.BAD_REQUEST, "Employee id doesn't exists")
                    );
        } catch (Exception e) {
            log.error("Exception in deletePost() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to delete details");
        }
    }

    /**
     * @param empId
     * @param updateEmpDetails
     * @return
     */

    public ResponseApi updateEmpDetails(
            final int empId,
            final UpdateEmpDetails updateEmpDetails
    ) {
        EmployeeCorpDetails details = empRepository.findById(empId).orElse(null);
        if (details == null) {
            return new ResponseApi(
                    HttpStatus.BAD_REQUEST,
                    "Employee id doesn't exist"
            );
        }
        try {
            if (
                    updateEmpDetails.getDesignation() != null
                            && !updateEmpDetails.getDesignation().isEmpty()
            ) {
                Designation designation = designationRepo.getDesignationName(
                        updateEmpDetails.getDesignation()
                );
                details.setDesignationId(designation.getDesignationId());
            }
            if (
                    updateEmpDetails.getTeam() != null
                            && !updateEmpDetails.getTeam().isEmpty()
            ) {
                Team team = teamRepo.findByTeamName(updateEmpDetails.getTeam());
                details.setTeamId(team.getTeamId());
            }
            if (
                    updateEmpDetails.getReportingManager() != null
                            && !updateEmpDetails.getReportingManager().isEmpty()
            ) {
                details.setReportingManager(updateEmpDetails.getReportingManager());
            }
            if (updateEmpDetails.getTerminationDate() != null) {
                details.setTerminationDate(updateEmpDetails.getTerminationDate());
            }
            //            if (updateEmpDetails.isPimcoUser()) {
            //                details.setIsPimcoUser(true);
            //                details.setPimcoUserId(updateEmpDetails.getPimcoUserId());
            //                details.setPimcoManager(updateEmpDetails.getPimcoManager());
            //            }
            return new ResponseApi(HttpStatus.OK, empRepository.save(details));
        } catch (Exception e) {
            log.error("Exception in updateEmpDetails() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update details"
            );
        }
    }

    /**
     * @param empId
     * @return
     */

    public EmployeeCorpDetails findById(final int empId) {
        try {
            return empRepository.findById(empId).orElse(null);
        } catch (Exception e) {
            log.error("Exception in findById() : {}", e.getMessage());
            return null;
        }
    }

    /**
     * @param details
     * @param designationId
     * @param teamId
     * @return
     */

    public ResponseApi addEmpDetails(
            final EmployeeCorpDetails details,
            final int designationId,
            final int teamId
    ) {
        try {
            details.setTeamId(teamRepo.findById(teamId).orElse(null).getTeamId());
            details.setDesignationId(
                    designationRepo.findById(designationId).orElse(null).getDesignationId()
            );
            EmployeeCorpDetails employeeHierarchy = empRepository.save(details);
            return new ResponseApi(HttpStatus.OK, employeeHierarchy);
        } catch (Exception e) {
            log.error("Exception in addEmpDetails() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to add Employee Details"
            );
        }
    }

    /**
     * @param lEmail
     * @return
     */

    public ResponseApi getUserDataByEmail(final List<String> lEmail) {
        try {
            Optional<List<EmployeeCorpDetails>> optional = empRepository.findByEmail(lEmail);
            if (optional.isEmpty()) {
                return new ResponseApi(
                        HttpStatus.BAD_REQUEST,
                        "Sorry!, This Email Id does not exist"
                );
            }
            List<EmployeeCorpDetails> lDetails = optional.get();
            List<UserData> lUserData = new ArrayList<>(0);
            lDetails.parallelStream().forEach(details -> {
                String designation = designationRepo
                        .findById(details.getDesignationId())
                        .orElse(null)
                        .getDesignationName();
                Team team = teamRepo.findById(details.getTeamId()).orElse(null);
                String userTeam = team.getTeamName();
                String userDept = departmentRepo
                        .findById(team.getDepartment())
                        .orElse(null)
                        .getDepartmentName();
                UserData userData = new UserData(
                        details.getEmployeeId(),
                        details.getEmail(),
                        details.getEmployeeCode(),
                        details.getEmployeeName(),
                        designation,
                        userDept,
                        details.getExtensionNo(),
                        details.getWorkStationNo(),
                        details.getContactNo(),
                        details.getProfileImagePath(),
                        userTeam,
                        details.getOfficeLocation(),
                        details.getReportingManager()
                );
                lUserData.add(userData);
            });
            return new ResponseApi(HttpStatus.OK, lUserData);
        } catch (Exception e) {
            log.error("Exception in getUserData() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to fetch employee details"
            );
        }
    }


    /**
     * CRON job to fetch Work Anniversary List
     *
     * @return
     */
    @PostConstruct
    @Scheduled(cron = "${CRON_EXP_6_AM}", zone = "Asia/Kolkata")
    public ResponseApi getAnniversaryList() {
        allWorkAnniversaryList.clear();
        try {
            allWorkAnniversaryList = empRepository.getUpcomingAnniversaries(getCurrentLocalDate(),
                    getCurrentLocalDate().plusDays(7));
            return new ResponseApi(HttpStatus.OK, allWorkAnniversaryList);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in getAnniversaryList() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch work anniversaries");
        }
    }

    /**
     * CRON job to fetch Birthday List
     *
     * @return
     */

    @PostConstruct
    @Scheduled(cron = "${CRON_EXP_6_AM}", zone = "Asia/Kolkata")
    public ResponseApi getBirthdayList() {
        allBirthdayList.clear();
        try {
            allBirthdayList = empRepository.getUpcomingBirthdays(getCurrentLocalDate(),
                    getCurrentLocalDate().plusDays(7));
            return new ResponseApi(HttpStatus.OK, allBirthdayList);
        } catch (Exception e) {
            log.error("Exception in getBirthdayList() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch the Birthday's list");
        }
    }

    /**
     * CRON job to fetch New Joiners List
     *
     * @return
     */

    @PostConstruct
    @Scheduled(cron = "${CRON_EXP_6_AM}", zone = "Asia/Kolkata")
    public ResponseApi getNewJoinersList() {
        allNewJoinersList.clear();
        try {
            allNewJoinersList = empRepository.getUpcomingNewJoiners(getCurrentLocalDate().minusDays(7));
            if (allNewJoinersList.isEmpty()) {
                return new ResponseApi(HttpStatus.NOT_FOUND, "No New Joiners found");
            }
            return new ResponseApi(HttpStatus.OK, allNewJoinersList);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in getNewJoinersList() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch new Joiners");
        }
    }

    /**
     * Method for various services to get the list of objects of the employee details and store it locally and use it as a cache!
     *
     * @return
     */

    public ResponseApi getEmployeesObjectsList() {
        try {
            return new ResponseApi(HttpStatus.OK, startUpInit.getAllEmpCorpDetails());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in getEmployeeCorpDetails() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to fetch employee details"
            );
        }
    }

    /**
     * @return
     */

    public ResponseApi getEmployeeDetails() {
        try {
            return new ResponseApi(HttpStatus.OK, repo.findAll());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Exception in getEmployeeCorpDetails() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch employee details"
            );
        }
    }

    /**
     * @return
     */
    public ResponseApi getOrganizationData() {
        try {
            List<OrganizationDto> list = empRepository.getOrganizationHierarchy();
            list.forEach(organizationDto -> {
                if (organizationDto.getEmployeeCode().equalsIgnoreCase("GSI N 001")) {
                    organizationDto.setManagerEmpCode(null);
                }
            });
            return new ResponseApi(HttpStatus.OK, list);
        } catch (Exception e) {
            log.error("Exception in getOrganizationData() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch employee details");
        }

    }

    /**
     * Removes all the extra uploaded profile images in S3
     *
     * @return
     */

    public ResponseApi deleteExtraProfileImagesInS3() {
        try {
            String status = startUpInit.deleteExtraProfileImagesFromS3Bucket();
            return new ResponseApi(HttpStatus.OK, status);
        } catch (Exception e) {
            log.error("Exception in deleteExtraProfileImagesInS3() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to delete extra profile images in S3");
        }
    }

    /**
     * fetch current localDate with Asia/Kolkata zone
     *
     * @return LocalDate
     */
    private LocalDate getCurrentLocalDate() {
        return LocalDate.now(ZoneId.of("Asia/Kolkata"));
    }
  /*
     try{
        ArrayList<UserData> UserDataList = new ArrayList<UserData>();
        // List<UserData> userDataList = null;
        List<EmployeeCorpDetails> list= empRepository.findAll();
        for (EmployeeCorpDetails details:list){
            String Email=details.getEmail();
            String EmployeeName= details.getEmployeeName();
            String designation=details.getDesignation().getDesignationName();
            String team=details.getTeam().getTeamName();
            String department=teamRepo.findById(details.getTeam().getTeamId()).orElse(null).getDepartment().getDepartmentName();
            String location=details.getLocation();
            String reportingManager=details.getReportingManager();
            UserData data=new UserData(employeeId,email,firstName,middleName,lastName,designation,department,team,location,reportingManager);
            uList.add(data);
        }
        return new ApiResponse(HttpStatus.OK,uList);
    }catch (Exception e){
        return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,null);
    }

     */
}

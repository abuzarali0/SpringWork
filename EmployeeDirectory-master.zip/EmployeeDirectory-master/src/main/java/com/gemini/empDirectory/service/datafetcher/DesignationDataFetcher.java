package com.gemini.empDirectory.service.datafetcher;

import com.gemini.empDirectory.model.Designation;
import com.gemini.empDirectory.repository.DesignationRepo;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DesignationDataFetcher implements DataFetcher<List<Designation>> {

    @Autowired
    private DesignationRepo designationRepo;

    /**
     *
     * @param dataFetchingEnvironment
     * @return
     */
    @Override
    public List<Designation> get(final DataFetchingEnvironment dataFetchingEnvironment) {
        List<Integer> desigIds = dataFetchingEnvironment.getArgument("ids");
        return designationRepo.findAllByIds(desigIds);
    }
}

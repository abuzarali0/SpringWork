package com.gemini.empDirectory.service;

import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.EmployeeCorpDetails;
import com.gemini.empDirectory.model.EmployeeLastJobDetails;
import com.gemini.empDirectory.repository.EmployeeLastJobDetailsRepository;
import com.gemini.empDirectory.repository.EmployeeRepository;
import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class EmployeeLastJobDetailsService {

    @Autowired
    private EmployeeLastJobDetailsRepository repository;

    @Autowired
    private EmployeeRepository employeeRepository;

    /**
     * Service method to fetch the last job details of the employee
     * @param empId
     * @param lastJobDetailId
     * @return
     */
    public ResponseApi getLastJobDetails(
            final Integer empId,
            final Integer lastJobDetailId
    ) {
        try {
            if (empId != null) {
                Optional<EmployeeLastJobDetails> employeeOptional = repository.findByEmpId(
                        empId
                );
                if (employeeOptional.isEmpty()) {
                    return new ResponseApi(
                            HttpStatus.NOT_FOUND,
                            "employee Id~ " + empId + " not found"
                    );
                }
                return new ResponseApi(HttpStatus.OK, employeeOptional.get());
            } else if (lastJobDetailId != null) {
                Optional<EmployeeLastJobDetails> lastJobDetailsOptional = repository.findById(
                        lastJobDetailId
                );
                if (lastJobDetailsOptional.isEmpty()) {
                    return new ResponseApi(
                            HttpStatus.NOT_FOUND,
                            "lastJobDetails Id~ " + lastJobDetailId + " is not found"
                    );
                }
                return new ResponseApi(HttpStatus.OK, lastJobDetailsOptional.get());
            } else {
                List<EmployeeLastJobDetails> lastJobDetailsList = repository.findAll();
                return new ResponseApi(HttpStatus.OK, lastJobDetailsList);
            }
        } catch (Exception e) {
            log.error("Exception in getLastJobDetails() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to fetch the last job details"
            );
        }
    }

    /**
     * service method to save the last job details of the employees
     * @param dto
     * @param empId
     * @return
     */
    public ResponseApi saveLastJobDetails(
            final EmployeeLastJobDetails dto,
            final Integer empId
    ) {
        try {
            Optional<EmployeeCorpDetails> employeeOptional = employeeRepository.findById(
                    empId
            );
            if (employeeOptional.isEmpty()) {
                return new ResponseApi(
                        HttpStatus.NOT_FOUND,
                        "employee Id~ " + empId + " not found"
                );
            }
            EmployeeLastJobDetails employeeLastJobDetails = new EmployeeLastJobDetails(
                    dto.getLastEmployerName(),
                    dto.getLastEmployerLocation(),
                    dto.getLastJobTenureInMonths(),
                    dto.getLastJobDesignation(),
                    dto.getJobLeavingReason()
            );
            employeeLastJobDetails.setEmp_id(empId);
            repository.save(employeeLastJobDetails);
            return new ResponseApi(
                    HttpStatus.OK,
                    "Employees last job details saved successfully!"
            );
        } catch (Exception e) {
            log.error("Exception in saveLastJobDetails() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to save the last job details"
            );
        }
    }

    /**
     * Service method to update the last job details of the employees
     * @param dto
     * @param lastJobDetailId
     * @return
     */
    public ResponseApi updateLastJobDetails(
            final EmployeeLastJobDetails dto,
            final Integer lastJobDetailId
    ) {
        try {
            Optional<EmployeeLastJobDetails> lastJobDetailsOptional = repository.findById(
                    lastJobDetailId
            );
            if (lastJobDetailsOptional.isEmpty()) {
                return new ResponseApi(
                        HttpStatus.NOT_FOUND,
                        "lastJobDetail Id~ " + lastJobDetailId + " not found"
                );
            }
            EmployeeLastJobDetails employeeLastJobDetails = new EmployeeLastJobDetails(
                    dto.getLastEmployerName(),
                    dto.getLastEmployerLocation(),
                    dto.getLastJobTenureInMonths(),
                    dto.getLastJobDesignation(),
                    dto.getJobLeavingReason()
            );
            employeeLastJobDetails.setEmp_id(dto.getEmp_id());
            employeeLastJobDetails.setEmployeeLastJobDetailsId(lastJobDetailId);
            repository.save(employeeLastJobDetails);
            return new ResponseApi(
                    HttpStatus.OK,
                    "Employees last job details updated successfully!"
            );
        } catch (Exception e) {
            log.error("Exception in updateLastJobDetails() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update the last job details"
            );
        }
    }
}

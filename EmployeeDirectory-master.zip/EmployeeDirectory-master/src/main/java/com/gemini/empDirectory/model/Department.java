package com.gemini.empDirectory.model;


import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "gemini_department")
public class Department {

    @Id
    @Column(name = "department_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(hidden = true)
    private int departmentId;

    @Column(name = "department_name")
    private String departmentName;

    public Department(final String departmentName) {
        this.departmentName = departmentName;
    }
}

package com.gemini.empDirectory.service;

import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.EmployeeSkills;
import com.gemini.empDirectory.repository.EmployeeRepository;
import com.gemini.empDirectory.repository.SkillRepository;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class SkillService {

    @Autowired
    private SkillRepository skillRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    /**
     * Method to get skill of an employee
     * @param empId
     * @return
     */

    public ResponseApi getSkillByEmpId(final int empId) {
        List<EmployeeSkills> skills;
        try {
            skills = skillRepository.getSkillsByEmpId(empId);
            return new ResponseApi(HttpStatus.OK, skills);
        } catch (Exception e) {
            log.error("Exception in getSkillByEmpId : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to fetch skills"
            );
        }
    }

    /**
     * Method to add a skill
     * @param skill
     * @param empId
     * @return
     */

    public ResponseApi addSkill(final EmployeeSkills skill, final int empId) {
        try {
            return employeeRepository
                    .findById(empId)
                    .map(
                            employee -> {
                                skill.setEmpId(employee.getEmployeeId());
                                skillRepository.save(skill);
                                return new ResponseApi(HttpStatus.OK, skill);
                            }
                    )
                    .orElse(
                            new ResponseApi(HttpStatus.BAD_REQUEST, "Employee id doesn't exist")
                    );
        } catch (Exception e) {
            log.error("Error while adding skill : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to add skill"
            );
        }
    }

    /**
     * Service method to delete a skill
     * @param skillId
     * @return
     */

    public ResponseApi deleteSkillById(final int skillId) {
        try {
            return skillRepository
                    .findById(skillId)
                    .map(
                            details -> {
                                skillRepository.delete(details);
                                return new ResponseApi(HttpStatus.OK, "Details Deleted");
                            }
                    )
                    .orElse(new ResponseApi(HttpStatus.BAD_REQUEST, "Id does not exist!"));
        } catch (Exception e) {
            log.error("Error while deleting skill Details : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete skill details"
            );
        }
    }
}

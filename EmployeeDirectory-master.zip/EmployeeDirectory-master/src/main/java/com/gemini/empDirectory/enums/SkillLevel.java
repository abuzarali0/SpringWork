package com.gemini.empDirectory.enums;

import lombok.Getter;

@Getter
public enum SkillLevel {
    BASIC,
    INTERMEDIATE,
    EXPERT
}

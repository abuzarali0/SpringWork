package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.model.EmployeeSkills;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SkillRepository extends JpaRepository<EmployeeSkills, Integer> {


    @Query(
            value = "select * from skills where employee = ?1", nativeQuery = true
    )
    List<EmployeeSkills> getSkillsByEmpId(int empId);

}

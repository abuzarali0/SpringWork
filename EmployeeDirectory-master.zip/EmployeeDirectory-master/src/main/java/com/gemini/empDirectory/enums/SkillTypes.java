package com.gemini.empDirectory.enums;

import lombok.Getter;

@Getter
public enum SkillTypes {
    PRIMARY,
    SECONDARY
}

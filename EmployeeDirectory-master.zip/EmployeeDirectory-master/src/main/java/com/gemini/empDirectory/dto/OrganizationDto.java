package com.gemini.empDirectory.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizationDto {

    private int employeeId;
    private String employeeCode;
    private String employeeName;
    private String profileImagePath;
    private String managerEmpCode;
    private String designationName;

    public OrganizationDto(final int employeeId, final String employeeCode, final String employeeName, final String profileImagePath,
                           final String managerEmpCode, final String designationName) {
        this.employeeId = employeeId;
        this.employeeCode = employeeCode;
        this.employeeName = employeeName;
        this.profileImagePath = profileImagePath;
        this.managerEmpCode = managerEmpCode;
        this.designationName = designationName;
    }
}

package com.gemini.empDirectory.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class UserAnniversaryDTO {
    private Integer empId;
    private String employeeName;
    private String email;
    private String anniversaryDate;
    private String imagePath;

    public UserAnniversaryDTO(
            final Integer empId, final String employeeName, final String email, final LocalDate anniversaryDate,
            final String imagePath
    ) {
        this.empId = empId;
        this.employeeName = employeeName;
        this.email = email;
        this.anniversaryDate = anniversaryDate.toString();
        this.imagePath = imagePath;
    }
}

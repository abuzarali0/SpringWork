package com.gemini.empDirectory.controller;

import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.EmployeeLastJobDetails;
import com.gemini.empDirectory.service.EmployeeLastJobDetailsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/emp-last-job-details")
@Tag(
        name = "Employee Last Job Details",
        description = "operations related to Employee last job details in EMS"
)
@Api(tags = { "Employee Last Job Details" })
public class EmployeeLastJobDetailsController {

    @Autowired
    private EmployeeLastJobDetailsService service;

    /**
     * Api method to get the last job details
     * @param empId
     * @param lastJobDetailId
     * @return
     */

    @ApiOperation(
            value = "view Employee Last Job Details",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully retrieved resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping
    public ResponseEntity<ResponseApi> getLastJobDetails(
            @ApiParam(
                    name = "empId",
                    type = "Integer",
                    value = "ID of Employee",
                    example = "1"
            ) final @RequestParam("empId") Integer empId,
            @ApiParam(
                    name = "lastJobDetailId",
                    type = "Integer",
                    value = "Employee Last job Detail Id",
                    example = "1"
            ) final @RequestParam("lastJobDetailId") Integer lastJobDetailId
    ) {
        ResponseApi responseApi = service.getLastJobDetails(empId, lastJobDetailId);
        log.info(
                "ResponseMessage for getLastJobDetails() is : {}",
                responseApi.getMessage()
        );
        return ResponseEntity.status(responseApi.getStatus()).body(responseApi);
    }

    /**
     * Api method to save the last job details of the employee
     * @param details
     * @param empId
     * @return
     */

    @ApiOperation(
            value = "add Employee last job Details by Employee ID",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully added resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to add the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to add is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to add is not found"
                    ),
            }
    )
    @PostMapping
    public ResponseEntity<ResponseApi> saveLastJobDetailsId(
            @ApiParam(
                    name = "Employee Last job Details",
                    value = "Last job Details of Employee"
            ) final @RequestBody EmployeeLastJobDetails details,
            @ApiParam(
                    name = "empId",
                    type = "Integer",
                    value = "ID of Employee",
                    example = "1"
            ) final @RequestParam("empId") Integer empId
    ) {
        ResponseApi responseApi = service.saveLastJobDetails(details, empId);
        log.info(
                "ResponseMessage for saveLastJobDetailsId() is : {}",
                responseApi.getMessage()
        );
        return ResponseEntity.status(responseApi.getStatus()).body(responseApi);
    }

    /**
     * Api method to update the last job details of the employee
     * @param details
     * @param lastJobDetailsId
     * @return
     */

    @ApiOperation(
            value = "update Employee Last Job Details",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully retrieved resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to update the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to update is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to update is not found"
                    ),
            }
    )
    @PutMapping
    public ResponseEntity<ResponseApi> updateLastJobDetails(
            @ApiParam(
                    name = "Employee Last job Details",
                    value = "Last job Details of Employee"
            ) final @RequestBody EmployeeLastJobDetails details,
            @ApiParam(
                    name = "lastJobDetailsId",
                    type = "Integer",
                    value = "Employee Last job Detail Id",
                    example = "1"
            ) final @RequestParam("lastJobDetailsId") Integer lastJobDetailsId
    ) {
        ResponseApi responseApi = service.updateLastJobDetails(
                details,
                lastJobDetailsId
        );
        log.info(
                "ResponseMessage for getPersonalDetails() is : {}",
                responseApi.getMessage()
        );
        return ResponseEntity.status(responseApi.getStatus()).body(responseApi);
    }
}

package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.model.EmployeePersonalDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeePersonalDetailsRepository
        extends JpaRepository<EmployeePersonalDetails, Integer> {
    @Query(nativeQuery = true,
            value = "select * from employee_personal_details where emp_id = ?"
    )
    Optional<EmployeePersonalDetails>  findByEmployeeId(Integer empId);

    @Override
    @Query(nativeQuery = true,
            value = "select * from employee_personal_details"
    )
    List<EmployeePersonalDetails> findAll();
}


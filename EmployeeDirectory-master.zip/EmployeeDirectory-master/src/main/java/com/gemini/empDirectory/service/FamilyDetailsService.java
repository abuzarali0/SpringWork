package com.gemini.empDirectory.service;

import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.EmpFamilyDetails;
import com.gemini.empDirectory.repository.EmployeeRepository;
import com.gemini.empDirectory.repository.FamilyDetailsRepo;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class FamilyDetailsService {

    @Autowired
    private FamilyDetailsRepo repository;

    @Autowired
    private EmployeeRepository employeeRepository;

    /**
     *
     * @param empId
     * @return
     */

    public ResponseApi getFamilyDetailsByEmpId(final int empId) {
        List<EmpFamilyDetails> familyDetails;
        try {
            familyDetails =
                    repository.findByEmpId(
                            employeeRepository.findById(empId).get().getEmployeeId()
                    );
            return new ResponseApi(HttpStatus.OK, familyDetails);
        } catch (Exception e) {
            log.error("Exception in getFamilyDetailsByEmpId : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to get Family Details"
            );
        }
    }

    /**
     *
     * @param empId
     * @param details
     * @return
     */
    public ResponseApi addFamilyDetails(
            final int empId,
            final EmpFamilyDetails details
    ) {
        try {
            return employeeRepository
                    .findById(empId)
                    .map(
                            employee -> {
                                details.setEmpId(empId);
                                repository.save(details);
                                return new ResponseApi(HttpStatus.OK, details);
                            }
                    )
                    .orElse(
                            new ResponseApi(HttpStatus.BAD_REQUEST, "Employee id doesn't exist")
                    );
        } catch (Exception e) {
            log.error("Error while adding family details : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to add family details"
            );
        }
    }

    /**
     * Method to Delete family details
     * @param familyDetailId
     * @return
     */

    public ResponseApi deleteFamilyDetails(final int familyDetailId) {
        try {
            return repository
                    .findById(familyDetailId)
                    .map(
                            details -> {
                                repository.delete(details);
                                return new ResponseApi(HttpStatus.OK, "Details Deleted");
                            }
                    )
                    .orElse(new ResponseApi(HttpStatus.BAD_REQUEST, "Id does not exist!"));
        } catch (Exception e) {
            log.error("Error while deleting family Details : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete family details"
            );
        }
    }
}

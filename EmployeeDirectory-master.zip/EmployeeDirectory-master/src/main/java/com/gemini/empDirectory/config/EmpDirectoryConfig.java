package com.gemini.empDirectory.config;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.regions.Region;

@Configuration
public class EmpDirectoryConfig {

    @Value("${ACCESS_KEY}")
    private String accessKey;

    @Value("${SECRET_KEY}")
    private String secretKey;

    /**
     * Bean for Amazon S3 Client
     *
     * @return
     */
    @Bean
    public AmazonS3 s3client() {

        Region region = Region.AP_SOUTH_1;
        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
        AmazonS3 amazonS3Client = AmazonS3ClientBuilder.standard()
                .withRegion(Regions.fromName(String.valueOf(region)))
                .withCredentials(
                        new AWSStaticCredentialsProvider(awsCredentials))
                .build();

        return amazonS3Client;
    }
}

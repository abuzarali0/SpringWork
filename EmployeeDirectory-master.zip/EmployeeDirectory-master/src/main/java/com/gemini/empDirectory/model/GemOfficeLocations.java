package com.gemini.empDirectory.model;

import com.gemini.empDirectory.generator.CustomLocationId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Table(name = "gemini_office_locations")
@Entity
@Getter
@Setter
public class GemOfficeLocations {
    @Id
    @Column(name = "address_id")
    @GenericGenerator(name = "location_id", strategy = "com.gemini.empDirectory.generator.CustomLocationId",
        parameters = {
            @org.hibernate.annotations.Parameter(name = CustomLocationId.VALUE_PREFIX_PARAMETER, value = "GEMO_"),
            @org.hibernate.annotations.Parameter(name = CustomLocationId.NUMBER_FORMAT_PARAMETER, value = "%04d")
        }
    )
    @GeneratedValue(generator = "location_id")
    @ApiModelProperty(hidden = true)
    private String addressId;

    @Column(name = "complete_address")
    @ApiModelProperty(notes = "Complete Address of the Employee")
    private String completeAddress;

    @Column(name = "city")
    @ApiModelProperty(notes = "City")
    private String city;

    @Column(name = "state")
    @ApiModelProperty(notes = "State")
    private String state;

    @Column(name = "country")
    @ApiModelProperty(notes = "Country")
    private String country;

    @Column(name = "pincode", length = 10)
    @ApiModelProperty(notes = "Pincode")
    private String pinCode;


}

package com.gemini.empDirectory.enums;

public enum Gender {
    MALE,
    FEMALE
}

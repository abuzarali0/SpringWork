package com.gemini.empDirectory.service.datafetcher;

import com.gemini.empDirectory.model.EmployeeCorpDetails;
import com.gemini.empDirectory.repository.EmployeeRepository;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AllEmpsDataFetcher implements DataFetcher<List<EmployeeCorpDetails>> {

    @Autowired
    private EmployeeRepository empRepository;

    /**
     *
     * @param dataFetchingEnvironment
     * @return
     */
    @Override
    public List<EmployeeCorpDetails> get(final DataFetchingEnvironment dataFetchingEnvironment) {
        return empRepository.findAll();
    }
}

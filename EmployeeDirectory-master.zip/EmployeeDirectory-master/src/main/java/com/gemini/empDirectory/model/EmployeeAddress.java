package com.gemini.empDirectory.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "address")
public class EmployeeAddress {

    @Id
    @Column(name = "address_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(hidden = true)
    private int addressId;

    @Column(name = "complete_address")
    @ApiModelProperty(notes = "Complete Address of the Employee")
    private String completeAddress;

    @Column(name = "city")
    @ApiModelProperty(notes = "City")
    private String city;

    @Column(name = "state")
    @ApiModelProperty(notes = "State")
    private String state;

    @Column(name = "country")
    @ApiModelProperty(notes = "Country")
    private String country;

    @Column(name = "pincode", length = 10)
    @ApiModelProperty(notes = "Pincode")
    private String pinCode;

    @Column(name = "is_address_permanent")
    private boolean isAddressPermanent;

    @Column(name = "emp_id")
    @ApiModelProperty(notes = "Employee Id")
    private Integer emp_id;

}

package com.gemini.empDirectory.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class BirthdayDTO {

    private Integer empId;
    private String employeeName;
    private String email;
    private String birthdayDate;
    private String imagePath;

    public BirthdayDTO(
            final Integer empId, final String employeeName, final String email, final LocalDate birthdayDate,
            final String imagePath
    ) {
        this.empId = empId;
        this.employeeName = employeeName;
        this.email = email;
        this.birthdayDate = birthdayDate.toString();
        this.imagePath = imagePath;
    }
}

package com.gemini.empDirectory.model;

import com.gemini.empDirectory.enums.Gender;
import com.gemini.empDirectory.enums.MaritalStatus;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "employee_personal_details")
public class EmployeePersonalDetails {
    @Id
    @Column(name = "emp_personal_details_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(notes = "employee personal details id")
    private Integer employeePersonalDetailId;

    @Column(name = "emp_id",  unique = true)
    @ApiModelProperty(notes = "employee id")
    private int empId;

    @Column(name = "personal_email")
    @ApiModelProperty(notes = "personal email of employee")
    private String PersonalEmail;

    @Column(name = "dob")
    @ApiModelProperty(notes = "employee date of birth")
    private LocalDate EmpDOB;

    //enum for blood groups
    @Column(name = "blood_group")
    @ApiModelProperty(notes = "employee blood group")
    private String BloodGroup;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "gender")
    @ApiModelProperty(notes = "employee gender")
    private Gender Gender;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "marital_status")
    @ApiModelProperty(notes = "marital status of employee")
    private MaritalStatus MaritalStatus;

    @Column(name = "pan_card_id")
    @ApiModelProperty(notes = "employee pan card number")
    private String PanCardId;

    @Column(name = "aadhaar_card_id")
    @ApiModelProperty(notes = "employee aadhaar card number")
    private String AadhaarCardId;

    @Column(name = "voter_card_id")
    @ApiModelProperty(notes = "employee voter id ")
    private String VoterCardId;

    @Column(name = "Driving_license_id")
    @ApiModelProperty(notes = "employee driving license number")
    private String DrivingLicenseId;

    @Column(name = "passport_id")
    @ApiModelProperty(notes = "employee passport id")
    private String PassportId;

    public EmployeePersonalDetails() {
        super();
    }

    public EmployeePersonalDetails(final String personalEmail, final LocalDate empDOB, final String bloodGroup, final Gender gender, final MaritalStatus maritalStatus,
                                   final String panCardId, final String aadhaarCardId, final String voterCardId, final String drivingLicenseId, final String passportId) {
        PersonalEmail = personalEmail;
        EmpDOB = empDOB;
        BloodGroup = bloodGroup;
        Gender = gender;
        MaritalStatus = maritalStatus;
        PanCardId = panCardId;
        AadhaarCardId = aadhaarCardId;
        VoterCardId = voterCardId;
        DrivingLicenseId = drivingLicenseId;
        PassportId = passportId;
    }

}

package com.gemini.empDirectory.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
public class UpdateEmpDetails {

    //private MaritalStatus maritalStatus;
    private String designation;
    private String team;
    private String ReportingManager;
    private LocalDate terminationDate;
    private boolean isPimcoUser;
    private String pimcoUserId;
    private String pimcoManager;

}

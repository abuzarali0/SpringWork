package com.gemini.empDirectory.service;

import com.gemini.empDirectory.repository.AddressRepository;
import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.EmployeeAddress;
import com.gemini.empDirectory.repository.EmployeeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class AddressService {

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

       /**
     *
     * @param empId
     * @return
     */
    public ResponseApi getAddressById(final int empId) {
        List<EmployeeAddress> address;
        try {
            address = addressRepository.getAddressByEmpId(employeeRepository.findById(empId).get().getEmployeeId());
            return new ResponseApi(HttpStatus.OK, address);
        } catch (Exception e) {
            log.error("Exception in getAddressById() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to get Address Details");

        }
    }

    /**
     *
     * @param address
     * @param empId
     * @return
     */

    public ResponseApi addAddress(final EmployeeAddress address, final int empId) {
        try {
            return employeeRepository.findById(empId).map(employee -> {
                address.setEmp_id(empId);
                addressRepository.save(address);
                return new ResponseApi(HttpStatus.OK, address);
            }).orElse(new ResponseApi(HttpStatus.BAD_REQUEST, "Employee id doesn't exist"));
        } catch (Exception e) {
            log.error("Error while adding address details : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to add address");
        }
    }

    /**
     *
     * @param addressId
     * @param address
     * @return
     */

    public ResponseApi updateAddress(final int addressId, final EmployeeAddress address) {
        try {
            return addressRepository.findById(addressId).map(updatedAddress -> {
                updatedAddress.setCompleteAddress(address.getCompleteAddress());
                updatedAddress.setCity(address.getCity());
                updatedAddress.setState(address.getState());
                updatedAddress.setCountry(address.getCountry());
                updatedAddress.setPinCode(address.getPinCode());
                return new ResponseApi(HttpStatus.OK, addressRepository.save(updatedAddress));
            }).orElse(new ResponseApi(HttpStatus.BAD_REQUEST, "Address id doesn't exist"));
        } catch (Exception e) {
            log.error("Exception in updateAddressById() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update address");
        }
    }

    /**
     *
     * @param addressId
     * @return
     */

    public ResponseApi deleteAddressById(final int addressId) {
        try {
            return addressRepository.findById(addressId).map(address -> {
                addressRepository.delete(address);
                return new ResponseApi(HttpStatus.OK, "Address deleted successfully");
            }).orElse(new ResponseApi(HttpStatus.BAD_REQUEST, "AddressId doesn't exist"));
        } catch (Exception e) {
            log.error("Exception in deleteAddressById() : {}", e.getMessage());
            return new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to delete address");
        }
    }
}

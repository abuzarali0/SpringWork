package com.gemini.empDirectory.service.datafetcher;

import com.gemini.empDirectory.model.EmployeeCorpDetails;
import com.gemini.empDirectory.repository.EmployeeRepository;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class EmpDataFetcher implements DataFetcher<List<EmployeeCorpDetails>> {

    @Autowired
    private EmployeeRepository empRepository;

    /**
     *
     * @param dataFetchingEnvironment
     * @return
     */
    @Override
    public List<EmployeeCorpDetails> get(final DataFetchingEnvironment dataFetchingEnvironment) {
        List<String> emails = dataFetchingEnvironment.getArgument("email");
        return empRepository.findByEmpCode(emails);
    }
}

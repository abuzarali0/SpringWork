package com.gemini.empDirectory.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "gemini_team")
public class Team {

    @Id
    @Column(name = "team_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(hidden = true)
    private int teamId;

    @Column(name = "team_name")
    private String teamName;

    @Column(name = "department_id")
    private int department;

    public Team(final String teamName, final int department) {
        this.teamName = teamName;
        this.department = department;
    }
}

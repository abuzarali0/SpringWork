package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface DepartmentRepo extends JpaRepository<Department, Integer> {

    @Query(nativeQuery = true,
    value = "select department_name from gemini_department")
    Set<String> getAllDepartments();

    //Department findByDepartmentName(String departmentName);

    @Query(nativeQuery = true,
    value = "select * from gemini_department where department_name=?1")
    Department getDeptName(String department);

    /**
     * For Graphql find by dept Ids.
     * @param deptIds
     * @return
     */
    @Query(nativeQuery = true,
            value = "select * from gemini_department where department_id IN (:deptIds)")
    List<Department> findByDeptIds(List<Integer> deptIds);

    @Override
    @Query(nativeQuery = true,
            value = "select * from gemini_department")
    List<Department> findAll();
}

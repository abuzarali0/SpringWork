package com.gemini.empDirectory.model;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Subselect;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee_directory_vw1")
@Immutable
@Subselect("select e.emp_id, e.contact_no, e.email, e.emp_code, e.employee_name, e.extension_no, "
        + "e.reporting_manager as reporting_manager_email, e.work_station_no, e.office_location, "
        + "d.department_name, t.team_name, de.designation_name, "
        + "e.image_s3_path as image_path, e.termination_date, "
        + "e.date_of_joining,e.is_fresher, epd.dob, "
        + "e1.emp_code as reporting_manager_code,e1.employee_name as reporting_manager_name "
        + "from employee_corp_details e "
        + "JOIN employee_corp_details e1 on e.reporting_manager=e1.email "
        + "LEFT JOIN gemini_team t on e.team_id=t.team_id "
        + "LEFT JOIN employee_personal_details epd ON epd.emp_id=e.emp_id " // dob
        + "LEFT JOIN gemini_designation de ON e.designation_id = de.designation_id "
        + "LEFT JOIN gemini_department d ON t.department_id=d.department_id "
        + "WHERE e.is_active_emp = true")
@Getter
@Setter
public class EmployeeDirectory {

    @Id
    private Integer empId;

    private String contactNo;

    private String email;

    private String empCode;

    private String employeeName;

    private String designationName;

    private String departmentName;

    private String teamName;

    private String extensionNo;

    private String workStationNo; //WsNo

    private String officeLocation;

    private String reportingManagerEmail;

    private String reportingManagerName;

    private String reportingManagerCode;

    private String imagePath;  // s3 image url added in this

    private String terminationDate;

    private String dateOfJoining;

    private Boolean isFresher;

    private String dob;


}

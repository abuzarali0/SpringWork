package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.model.GemOfficeLocations;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OfficeLocationRepo extends JpaRepository<GemOfficeLocations, String> {
}

package com.gemini.empDirectory.service.datafetcher;

import com.gemini.empDirectory.model.Team;
import com.gemini.empDirectory.repository.DepartmentRepo;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DepartmentResolverFetcher {
    @Autowired
    private DepartmentRepo departmentRepo;
    @Autowired
    private TeamResolverFetcher teamResolverFetcher;

    /**
     * Get Department of the team
     * @return
     */
    public DataFetcher getDepartmentForTeam() {
        return dataFetchingEnvironment -> {
          Team team = dataFetchingEnvironment.getSource();
          return departmentRepo.findById(team.getDepartment());
        };
    }
}

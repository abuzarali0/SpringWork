package com.gemini.empDirectory.controller;

import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.EmpFamilyDetails;
import com.gemini.empDirectory.service.EmployeeService;
import com.gemini.empDirectory.service.FamilyDetailsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/emp-family-details")
@Tag(
        name = "Employee Family Details",
        description = "operations related to Employee Family details in EMS"
)
@Api(tags = { "Employee Family Details" })
public class FamilyDetailsController {

    @Autowired
    private FamilyDetailsService service;

    @Autowired
    private EmployeeService employeeService;

    /**
     *
     * @param empId
     * @return
     */

    @ApiOperation(
            value = "view Employee Family Details by Employee ID",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully retrieved resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping
    public ResponseEntity<ResponseApi> getDetailsByEmpId(
            @ApiParam(
                    name = "empId",
                    type = "Integer",
                    value = "ID of Employee",
                    example = "1"
            ) final @RequestParam(value = "empId") int empId
    ) {
        if (employeeService.findById(empId) == null) {
            ResponseApi response = new ResponseApi(
                    HttpStatus.BAD_REQUEST,
                    "Employee Id doesn't exist"
            );
            return ResponseEntity.status(response.getStatus()).body(response);
        }
        ResponseApi response = service.getFamilyDetailsByEmpId(empId);
        log.info(
                "ResponseMessage for getDetailsByEmpId() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     *
     * @param details
     * @param empId
     * @return
     */

    @ApiOperation(
            value = "add Employee Family Details by Employee ID",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully added resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to add the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to add is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to add is not found"
                    ),
            }
    )
    @PostMapping
    public ResponseEntity<ResponseApi> addFamilyDetails(
            @ApiParam(
                    name = "Employee family details",
                    value = "Family details of the Employee"
            ) final @RequestBody EmpFamilyDetails details,
            @ApiParam(
                    name = "empId",
                    type = "Integer",
                    value = "ID of Employee",
                    example = "1"
            ) final @RequestParam(value = "empId") int empId
    ) {
        if (employeeService.findById(empId) == null) {
            ResponseApi response = new ResponseApi(
                    HttpStatus.BAD_REQUEST,
                    "Employee Id doesn't exist"
            );
            return ResponseEntity.status(response.getStatus()).body(response);
        }
        ResponseApi response = service.addFamilyDetails(empId, details);
        log.info(
                "ResponseMessage for addFamilyDetails() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     *
     * @param familyDetailId
     * @return
     */

    @ApiOperation(
            value = "delete Employee family details by Family Detail ID",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully deleted resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to delete the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to delete is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to delete is not found"
                    ),
            }
    )
    @DeleteMapping
    public ResponseEntity<ResponseApi> deleteFamilyDetails(
            @ApiParam(
                    name = "familyDetailId",
                    type = "Integer",
                    value = "Family detail id of the employee",
                    example = "1"
            ) final @RequestParam(value = "familyDetailId") int familyDetailId
    ) {
        ResponseApi response = service.deleteFamilyDetails(familyDetailId);
        log.info(
                "ResponseMessage for deleteFamilyDetails() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }
}

package com.gemini.empDirectory.service.datafetcher;

import com.gemini.empDirectory.model.Department;
import com.gemini.empDirectory.repository.DepartmentRepo;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AllDepartmentsDataFetcher implements DataFetcher<List<Department>> {

    @Autowired
    private DepartmentRepo departmentRepo;

    /**
     *
     * @param dataFetchingEnvironment
     * @return
     */
    @Override
    public List<Department> get(final DataFetchingEnvironment dataFetchingEnvironment) {
        return departmentRepo.findAll();
    }
}

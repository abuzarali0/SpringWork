package com.gemini.empDirectory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

//mvn spotbugs:check
//mvn [target] -Dcheckstyle.skip

@SpringBootApplication
public class MisApplication {

	public static void main(final String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(MisApplication.class, args);

        context.getBean(StartUpInit.class).init();
	}

}

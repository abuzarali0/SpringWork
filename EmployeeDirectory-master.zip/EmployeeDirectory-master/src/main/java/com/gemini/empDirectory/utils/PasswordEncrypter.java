package com.gemini.empDirectory.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.*;

@Slf4j
@Component
public class PasswordEncrypter {

    /**
     * this method accept a String and converts it into a hash using SHA256 algorithm
     *
     * @param password
     *
     * @return String encrypted hash password
     */
    public String encrypt(final String password) {
        String generatedPassword = null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            byte[] bytes = md.digest(password.getBytes(StandardCharsets.UTF_8));


            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16)
                                 .substring(1));
            }

            generatedPassword = sb.toString();
        } catch (Exception e) {
            log.error("Exception while encrypting password , Error : " + e.getMessage());
        }
        return generatedPassword;
    }
}

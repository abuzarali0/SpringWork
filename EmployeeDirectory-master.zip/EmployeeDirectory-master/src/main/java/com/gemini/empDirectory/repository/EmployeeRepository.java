package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.dto.BirthdayDTO;
import com.gemini.empDirectory.dto.NewJoinersDTO;
import com.gemini.empDirectory.dto.OrganizationDto;
import com.gemini.empDirectory.dto.UserAnniversaryDTO;
import com.gemini.empDirectory.model.EmployeeCorpDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeCorpDetails, Integer> {

    @Query(value = "select email from employee_corp_details", nativeQuery = true)
    Set<String> getAllEmails();

    @Query(nativeQuery = true,
            value = "select * from employee_corp_details where email in (?1)")
    Optional<List<EmployeeCorpDetails>> findByEmail(List<String> lEmail);

    @Query(nativeQuery = true,
            value = "select * from employee_corp_details where email IN (:emails)")
    List<EmployeeCorpDetails> findByEmpCode(List<String> emails);

    String GET_UPCOMING_ANNIVERSARIES = "SELECT new com.gemini.empDirectory.dto.UserAnniversaryDTO(employeeId,"
            + "employeeName,"
            + "email,"
            + "dateOfJoining,"
            + "profileImageS3Path) "
            + "FROM EmployeeCorpDetails "
            + "WHERE TO_DATE(TO_CHAR(dateOfJoining,'DD-MM'),'DD-MM') "
            + "BETWEEN TO_DATE(TO_CHAR(TO_TIMESTAMP(:currentDate,'YYYY-MM-DD'),'DD-MM'),'DD-MM') "
            + "AND TO_DATE(TO_CHAR( TO_TIMESTAMP( :futureDate,'YYYY-MM-DD'),'DD-MM'),'DD-MM') "
            + "order by TO_DATE(TO_CHAR(dateOfJoining,'DD-MM'),'DD-MM')";

    // futureDate passed in param is currentDate + 7 days
    @Query(value = GET_UPCOMING_ANNIVERSARIES)
    List<UserAnniversaryDTO> getUpcomingAnniversaries(@Param("currentDate") LocalDate currentDate, @Param("futureDate") LocalDate futureDate);


    String GET_UPCOMING_BIRTHDAYS = "SELECT new com.gemini.empDirectory.dto.BirthdayDTO(emp.employeeId,"
            + "emp.employeeName,"
            + "emp.email,"
            + "personal.EmpDOB,"
            + "emp.profileImageS3Path) "
            + "FROM EmployeePersonalDetails personal "
            + "INNER JOIN EmployeeCorpDetails emp on emp.employeeId = personal.empId "
            + "WHERE TO_DATE(TO_CHAR(personal.EmpDOB,'DD-MM'),'DD-MM') "
            + "BETWEEN TO_DATE(TO_CHAR(TO_TIMESTAMP(:currentDate,'YYYY-MM-DD'),'DD-MM'),'DD-MM') "
            + "AND TO_DATE(TO_CHAR( TO_TIMESTAMP( :futureDate,'YYYY-MM-DD'),'DD-MM'),'DD-MM') "
            + "order by TO_DATE(TO_CHAR(personal.EmpDOB,'DD-MM'),'DD-MM') ";

    // futureDate passed in param is currentDate + 7 days
    @Query(value = GET_UPCOMING_BIRTHDAYS)
    List<BirthdayDTO> getUpcomingBirthdays(@Param("currentDate") LocalDate currentDate, @Param("futureDate") LocalDate futureDate);

    String GET_UPCOMING_NEW_JOINERS = "SELECT new com.gemini.empDirectory.dto.NewJoinersDTO(emp.employeeId,"
            + "emp.email,"
            + "emp.dateOfJoining,"
            + "emp.employeeName,"
            + "emp.profileImageS3Path) "
            + "FROM EmployeeCorpDetails emp "
            + "where emp.dateOfJoining >= :date "
            + "order by emp.dateOfJoining ";

    // date passed in param is currentDate - 7 days
    @Query(value = GET_UPCOMING_NEW_JOINERS)
    List<NewJoinersDTO> getUpcomingNewJoiners(@Param("date") LocalDate date);

    String GET_ORGANIZATION_STRUCTURE = "SELECT new com.gemini.empDirectory.dto.OrganizationDto(emp.employeeId, "
            + "emp.employeeCode, "
            + "emp.employeeName, "
            + "emp.profileImagePath, "
            + "managerEmp.employeeCode, "
            + "d.designationName) "
            + "FROM EmployeeCorpDetails emp "
            + "LEFT JOIN Designation d ON (emp.designationId = d.designationId)"
            + "LEFT JOIN EmployeeCorpDetails managerEmp ON (managerEmp.email = emp.reportingManager )";
    @Query(value = GET_ORGANIZATION_STRUCTURE)
    List<OrganizationDto> getOrganizationHierarchy();
}


package com.gemini.empDirectory.controller;
import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.GemOfficeLocations;
import com.gemini.empDirectory.repository.OfficeLocationRepo;
import com.gemini.empDirectory.service.OfficeLocationsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping(value = "/office-locations")
@Tag(
        name = "Gemini Office Locations",
        description = "operations related of gemini office locations"
)
@Api(tags =  {"Gemini Office Locations"})
public class OfficeLocationsController {

    @Autowired
    private OfficeLocationRepo officeLocationRepo;

    @Autowired
    private OfficeLocationsService officeLocationsService;


    /**
     * Fetch all office locations
     * @return
     */
    @GetMapping()
    public ResponseEntity<ResponseApi> getAllOfficeLocations() {
        ResponseApi response =  officeLocationsService.getAllOfficeLocations();

        log.info(
                "Response message for getAllOfficeLocations() is : {}",
                response.getMessage()
        );

        return ResponseEntity.status(response.getStatus()).body(response);
    }




    /**
     * Fetch office location of given Id
     * @param addressId
     * @return
     */
    @GetMapping("/{addressId}")
    public ResponseEntity<ResponseApi> getOfficeLocationById(
            @ApiParam(
                    name = "addressId",
                    type = "String",
                    value = "Address Id Of Location to be fetched",
                    example = "GEMO_0001"
            ) final @PathVariable(value = "addressId") String addressId
    ) {
        ResponseApi response = officeLocationsService.getOfficeLocationById(addressId);

        log.info(
                "Response message for getOfficeLocationById() is : {}",
                response.getMessage()
        );

        return ResponseEntity.status(response.getStatus()).body(response);
    }




    /**
     * add new office location to db
     * @param gemOfficeLocations
     * @return
     */
    @PostMapping()
    public ResponseEntity<ResponseApi> addOfficeLocation(
            @ApiParam(
                    name = "gemOfficeLocations",
                    type = "GemOfficeLocations",
                    value = "Address Of Gemini Office Location to be added"
            ) final @RequestBody GemOfficeLocations gemOfficeLocations
    ) {
        ResponseApi response = officeLocationsService.addOfficeLocation(gemOfficeLocations);

        log.info(
                "Response message for addOfficeLocation() is : {}",
                response.getMessage()
        );

        return ResponseEntity.status(response.getStatus()).body(response);
    }




    /**
     * Update office location of given Id
     * @param addressId
     * @param gemOfficeLocation
     * @return
     */
    @PutMapping("/{addressId}")
    public ResponseEntity<ResponseApi> updateOfficeLocation(
            @ApiParam(
                    name = "addressId",
                    type = "String",
                    value = "Address Id of location to be updated",
                    example = "GEMO_0001"

            ) final @PathVariable String addressId,
            @ApiParam(
                    name = "gemOfficeLocation",
                    type = "GemOfficeLocations",
                    value = "Updated Address Of Gemini Office Location"
            ) final @RequestBody GemOfficeLocations gemOfficeLocation
    ) {
        ResponseApi response = officeLocationsService.updateOfficeLocation(addressId, gemOfficeLocation);

        log.info(
                "Response message for updateOfficeLocation() is {}",
                response.getMessage()
        );

        return ResponseEntity.status(response.getStatus()).body(response);
    }




    /**
     * delete office location of given Id
     * @param addressId
     * @return
     */
    @DeleteMapping("/{addressId}")
    public ResponseEntity<ResponseApi> deleteOfficeLocationById(
            @ApiParam(
                    name = "addressId",
                    type = "String",
                    value = "Address Id Of Location to be fetched",
                    example = "GEMO_0001"
            ) final @PathVariable String addressId
    ) {
        ResponseApi response = officeLocationsService.deleteOfficeLocationById(addressId);

        log.info(
                "Response message for deleteOfficeLocationById() is {}",
                response.getMessage()
        );

        return ResponseEntity.status(response.getStatus()).body(response);
    }
}

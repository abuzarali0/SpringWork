package com.gemini.empDirectory.service;

import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.GemOfficeLocations;
import com.gemini.empDirectory.repository.OfficeLocationRepo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class OfficeLocationsService {

    @Autowired
    private OfficeLocationRepo officeLocationRepo;



    /**
     * Fetch All Office Locations
     * @return
     */
    public ResponseApi getAllOfficeLocations() {
        List<GemOfficeLocations> officeLocationsList;
        try {
            officeLocationsList = officeLocationRepo.findAll();
            return new ResponseApi(HttpStatus.OK, officeLocationsList);
        } catch (Exception e) {
            log.error("Exception in getAllOfficeLocations() : {}", e.getMessage());
            return  new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to fetch Office Location details"
            );
        }
    }




    /**
     * Fetch Office Location By Id
     * @param addressId
     * @return
     */
    public ResponseApi getOfficeLocationById(final String addressId) {
        try {

            return officeLocationRepo
                    .findById(addressId)
                    .map(
                            gemOfficeLocation -> {
                                return new ResponseApi(HttpStatus.OK, gemOfficeLocation);
                            }
                    ) .orElse(
                            new ResponseApi(HttpStatus.BAD_REQUEST, "Employee id doesn't exist")
                    );
        } catch (Exception e) {
            log.error("Exception in getOfficeLocationById() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to get Office Location details"
            );
        }
    }




    /**
     * Add new Office Location
     * @param gemOfficeLocation
     * @return
     */

    public ResponseApi addOfficeLocation(final GemOfficeLocations gemOfficeLocation) {
        try {
            GemOfficeLocations addedOfficeLocation = officeLocationRepo.save(gemOfficeLocation);
            return new ResponseApi(HttpStatus.OK, addedOfficeLocation);
        } catch (Exception e) {
            log.error("Exception in addOfficeLocation() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to add Office Location");
        }
    }




    /**
     * Update Office Location By AdddressId
     * @param addressId
     * @param gemOfficeLocation
     * @return
     */
    public ResponseApi updateOfficeLocation(final String addressId, final GemOfficeLocations gemOfficeLocation) {
        try {
            Optional<GemOfficeLocations> optional = officeLocationRepo.findById(addressId);

            if (optional.isEmpty()) {
                return new ResponseApi(
                        HttpStatus.BAD_REQUEST,
                        "Address Id: " + addressId + "doesn't exist"
                );
            }

            GemOfficeLocations updatedOfficeLocation = optional.get();
            updatedOfficeLocation.setCity(gemOfficeLocation.getCity());
            updatedOfficeLocation.setCompleteAddress(gemOfficeLocation.getCompleteAddress());
            updatedOfficeLocation.setCountry(gemOfficeLocation.getCountry());
            updatedOfficeLocation.setPinCode(gemOfficeLocation.getPinCode());
            updatedOfficeLocation.setState(gemOfficeLocation.getState());
            officeLocationRepo.save(updatedOfficeLocation);

            return new ResponseApi(HttpStatus.OK, "Office Location Updated Successfully");

        } catch (Exception e) {
            log.error("Exception in updateOfficeLocation() : {}", e.getMessage());
            return  new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update Office Location details."
            );
        }
    }




    /**
     * Delete Office Location By Address Id
     * @param addressId
     * @return
     */
    public ResponseApi deleteOfficeLocationById(final String addressId) {
        try {
            Optional<GemOfficeLocations> optional = officeLocationRepo.findById(addressId);

            if (optional.isEmpty()) {
                return new ResponseApi(
                        HttpStatus.BAD_REQUEST,
                        "Address Id: " + addressId + "doesn't exist"
                );
            }

            officeLocationRepo.deleteById(addressId);
            return new ResponseApi(HttpStatus.OK, "Office Location of Id: " + addressId + "is deleted");
        } catch (Exception e) {
            log.error("Exception in deleteOfficeLocationById() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete Office Location of Id: " + addressId
            );
        }
    }
}

package com.gemini.empDirectory.model;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.gemini.empDirectory.enums.SkillLevel;
import com.gemini.empDirectory.enums.SkillTypes;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "skills")
public class EmployeeSkills {

    @Id
    @Column(name = "skill_id")
    @ApiModelProperty(hidden = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int skillId;

    @Column(name = "skill_name")
    @ApiModelProperty(notes = "employee skill")
    private String skillName;

    @Enumerated(EnumType.STRING)
    @Column(name = "skill_type")
    @ApiModelProperty(notes = "type of the skill")
    private SkillTypes skillType;   //Primary or Secondary (skillType)

    @Enumerated(EnumType.STRING)
    @Column(name = "skill_level")
    @ApiModelProperty(notes = "skill level")
    private SkillLevel skillLevel; //basic,intermediate,expert

    @Column(name = "experience")
    @ApiModelProperty(notes = "total experience")
    private int monthsOfExperience;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Column(name = "create_date")
    private LocalDateTime createDate;

    @Column(name = "isActive")
    private boolean isActive;

    @ApiModelProperty(hidden = true)
    @Column(name = "employee")
    private int empId;

}

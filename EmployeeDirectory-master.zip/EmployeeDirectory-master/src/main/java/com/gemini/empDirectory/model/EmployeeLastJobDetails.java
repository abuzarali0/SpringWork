package com.gemini.empDirectory.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "employee_last_job_details")
public class EmployeeLastJobDetails {
    @Id
    @ApiModelProperty(hidden = true)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer employeeLastJobDetailsId;

    @Column(name = "emp_id", unique = true)
    @ApiModelProperty(notes = "Employee Id")
    private int emp_id;

    @Column(name = "last_employer_name")
    @ApiModelProperty(notes = "Last Employer name")
    private String LastEmployerName;

    @Column(name = "lastEmployerLocation")
    @ApiModelProperty(notes = "last employer location")
    private String LastEmployerLocation;

    @Column(name = "last_job_tenure")
    @ApiModelProperty(notes = "last job tenure")
    private int LastJobTenureInMonths;

    @Column(name = "last_job_designation")
    @ApiModelProperty(notes = "last job designation")
    private String LastJobDesignation;

    @Column(name = "job_leaving_reason")
    @ApiModelProperty(notes = "reason for leaving last job")
    private String JobLeavingReason;

    public EmployeeLastJobDetails(final String lastEmployerName, final String lastEmployerLocation, final int lastJobTenureInMonths,
                                  final String lastJobDesignation, final String jobLeavingReason) {
        LastEmployerName = lastEmployerName;
        LastEmployerLocation = lastEmployerLocation;
        LastJobTenureInMonths = lastJobTenureInMonths;
        LastJobDesignation = lastJobDesignation;
        JobLeavingReason = jobLeavingReason;
    }
}

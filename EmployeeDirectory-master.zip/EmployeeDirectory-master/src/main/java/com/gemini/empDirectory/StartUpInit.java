package com.gemini.empDirectory;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gemini.empDirectory.utils.PasswordEncrypter;
import com.gemini.empDirectory.model.*;
import com.gemini.empDirectory.repository.*;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
@EnableScheduling
public class StartUpInit {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DesignationRepo designationRepo;

    @Autowired
    private TeamRepo teamRepo;

    @Autowired
    private DepartmentRepo departmentRepo;

    @Autowired
    private PasswordEncrypter encrypter;

    @Value("${MIS_API}")
    private String misApi;

    @Value("${BUCKET}")
    private String bucket;

    @Value("${ACCESS_KEY}")
    private String accessKey;

    @Value("${SECRET_KEY}")
    private String secretKey;

    @Value("${AWS_ACTIVE}")
    private boolean awsActive;

    @Value("${IMAGE_PREFIX_S3}")
    private String imagePrefix;

    private List<EmployeeCorpDetails> allEmpCorpDetails = new ArrayList<>(0);

    private List<EmployeeCorpDetails> allEmployee = new ArrayList<>(0);

    @Autowired
    private EmployeePersonalDetailsRepository empPersonalRepository;

    @Autowired
    private AmazonS3 amazonS3Client;

    /**
     * This set holds all the Profile Image keys present in S3
     */
    private Set<String> profileImageHashSet = new HashSet<>();

    /**
     * CRON job to fetch Employee Details
     */
    @Scheduled(cron = "${CRON_EXP}", zone = "Asia/Kolkata")
    public void init() {
        log.info("Current time is :: " + Calendar.getInstance().getTime());
        allEmpCorpDetails.clear();
        try {

            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            HttpEntity<String> entity = new HttpEntity<>(headers);
            ResponseEntity<String> response
                    = restTemplate.exchange(misApi, HttpMethod.GET, entity, String.class);
            log.info("response status from MIS api : {}", response.getStatusCode());
            ObjectMapper mapper = new ObjectMapper();
            JsonNode respObj = mapper.readTree(response.getBody());
            List<MISEmpDetails> origEmpList = new Gson().fromJson(respObj.get("Result").toString(),
                    new TypeToken<List<MISEmpDetails>>() {
                    }.getType());

            List<MISEmpDetails> empListNN =
                    origEmpList.stream().filter(e -> e.getEmail() != null).collect(Collectors.toList());

            UpdateEmpCorpDetails(empListNN);
            updateEmpPersonalDetails(empListNN);
            checkEmpIsActive(empListNN);
            loadAllImageFromBucket();
            log.info("Completed");
        } catch (RuntimeException e) {
            log.error("Encountered runtime Exception in init()");
            throw e;
        } catch (Exception e) {
            log.error("Exception in init() : {}", e.getMessage());
        }
    }

    /**
     * Updating Employee corporate details.
     *
     * @param origEmpList
     */
    private void UpdateEmpCorpDetails(final List<MISEmpDetails> origEmpList) {
        log.info("Adding/ Updating Emp Corp Details.");
        try {
            // Fetching Details
            List<Designation> designationList = designationRepo.findAll();
            Map<String, Integer> designationMap = designationList.stream().collect(
                    Collectors.toMap(designation -> designation.getDesignationName(),
                            designation -> designation.getDesignationId()));
            // To fetch designation name from designation id in case emp corp update.
            // This is created so that we dont have to make DB calls to fetch designation name based
            // on id stored in emp corp table.
            Map<Integer, String> desigMapRev = designationList.stream().collect(
                    Collectors.toMap(designation -> designation.getDesignationId(),
                            designation -> designation.getDesignationName()));


            List<Team> teamList = teamRepo.findAll();
            Map<String, Integer> teamMap = teamList.stream().collect(
                    Collectors.toMap(team -> team.getTeamName(),
                            team -> team.getTeamId()));
            // To fetch team name from team id in case emp corp update.
            // This is created so that we dont have to make DB calls to fetch team name based
            // on id stored in emp corp table.
            Map<Integer, String> tMapRev = teamList.stream().collect(
                    Collectors.toMap(team -> team.getTeamId(),
                            team -> team.getTeamName()));

            List<Department> departmentList = departmentRepo.findAll();
            Map<String, Integer> departmentMap = departmentList.stream().collect(
                    Collectors.toMap(dept -> dept.getDepartmentName(),
                            dept -> dept.getDepartmentId()));

            List<EmployeeCorpDetails> employeeHierarchyList = new ArrayList<>();
            Set<String> emailSet = employeeRepository.getAllEmails();

            origEmpList.stream().forEach(origEmp -> {
                String email = origEmp.getEmail().toLowerCase(Locale.ROOT);
                String employeeName = origEmp.getEmployeeName().trim();

                String empCode = origEmp.getEmployeeCode();

                String designation = origEmp.getDesignation().trim();
                if (!designationMap.keySet().contains(designation)) {
                    Designation d = designationRepo.save(new Designation(designation));
                    designationMap.put(designation, d.getDesignationId());
                    log.info("New Designation {} added", designation);
                }
                String department = origEmp.getDepartmentName().trim();
                if (!departmentMap.keySet().contains(department)) {
                    Department dt = departmentRepo.save(new Department(department));
                    departmentMap.put(department, dt.getDepartmentId());
                    log.info("New Department {} added", department);
                }

                String team = origEmp.getTeam().trim().toUpperCase();
                if (!teamMap.keySet().contains(team)) {
                    Team t = teamRepo.save(new Team(team, departmentMap.get(department)));
                    teamMap.put(team, t.getTeamId());
                    log.info("New Team {} added", team);
                }


                String location = origEmp.getLocation().trim();
                String reportingManagerEmail = origEmp.getManagerEmail().trim();
                String mobileNo = origEmp.getMobileNumber();
                String extNo = origEmp.getExtNo();
                String wsNo = origEmp.getWsNo();
                String imagePath = origEmp.getImagePath();
                String strJoiningDate = origEmp.getJoiningDate();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
                LocalDate joiningDate = LocalDate.parse(strJoiningDate, formatter);
                boolean isFresher = Boolean.valueOf(origEmp.getIsFresher());

                if (email != null) {
                    if (!emailSet.contains(email)) {
                        String profileImageS3Path = null;
                        profileImageS3Path = storeImagesToS3Bucket(imagePath, email);
                        EmployeeCorpDetails employee = new EmployeeCorpDetails(empCode, email, employeeName,
                                mobileNo, extNo, wsNo, location, reportingManagerEmail, imagePath, joiningDate,
                                isFresher, profileImageS3Path);
                        employee.setDesignationId(designationMap.get(designation));
                        employee.setTeamId(teamMap.get(team));
                        employeeHierarchyList.add(employee);
                        log.info("Employee Details with email : {} added successfully", email);
                    } else {
                        Optional<List<EmployeeCorpDetails>> employeeOptional =
                                employeeRepository.findByEmail(Arrays.asList(email));
                        if (employeeOptional.isPresent() && employeeOptional.get().size() > 0) {
                            EmployeeCorpDetails employee = employeeOptional.get().get(0);
                            if (!employee.getEmail().equalsIgnoreCase(email)) {
                                employee.setEmail(email);
                            }
                            if (!employee.getEmployeeCode().equalsIgnoreCase(empCode)) {
                                employee.setEmployeeCode(empCode);
                            }
                            if (!desigMapRev.get(employee.getDesignationId()).equals(designation)) {
                                employee.setDesignationId(designationMap.get(designation));
                            }
                            if (!tMapRev.get(employee.getTeamId()).equals(team)) {
                                employee.setTeamId(teamMap.get(team));
                            }
                            if (!employee.getReportingManager().equals(reportingManagerEmail)) {
                                employee.setReportingManager(reportingManagerEmail);
                            }
                            String empDOJ = String.valueOf(employee.getDateOfJoining());
                            String misDOJ = String.valueOf(joiningDate);
                            if (!empDOJ.equalsIgnoreCase(misDOJ)) {
                                employee.setDateOfJoining(joiningDate);
                            }
                            if (employee.isFresher() != isFresher) {
                                employee.setFresher(isFresher);
                            }
                            if (employee.getProfileImageS3Path() == null
                                    || !imagePath.equalsIgnoreCase(employee.getProfileImagePath())) {
                                String profileImageS3Path = storeImagesToS3Bucket(imagePath, email);
                                employee.setProfileImageS3Path(profileImageS3Path);
                                employee.setProfileImagePath(imagePath);
                            }
                            EmployeeCorpDetails savedEmployee = null;
                            try {
                                savedEmployee = employeeRepository.save(employee);
                            } catch (Exception e) {
                                log.error("Error saving emp corp details : {}", e.getMessage());
                            }
                            allEmpCorpDetails.add(savedEmployee);
                        }
                    }
                }
            });
            List<EmployeeCorpDetails> savedList = employeeRepository.saveAll(employeeHierarchyList);
            log.info("Saved " + savedList.size() + " new emp(s) details on " + Calendar.getInstance().getTime());
            allEmpCorpDetails.addAll(savedList);
        } catch (Exception e) {
            log.error("Error updating emp corp details : {}", e.getMessage());
        }
        log.info("Add/Update Emp Corp Details : Complete");
    }

    /**
     * Save Employee DOB in Employee Personal Details Table
     */
    private void updateEmpPersonalDetails(final List<MISEmpDetails> origEmpList) {
        log.info("Starting to update Emp Personal details.");
        try {
            //fetch all emps personal details
            List<EmployeePersonalDetails> employeePersonalDetailsList = empPersonalRepository.findAll();

            // create a map
            Map<Integer, EmployeePersonalDetails> empPersonalDtMap = employeePersonalDetailsList.stream().collect(
                    Collectors.toMap(personalDetails -> personalDetails.getEmpId(),
                            personalDetails -> personalDetails));

            //fetch all email and DOB we got from MIS API
            Map<String, String> origEmpEmailDobMap = origEmpList.stream().collect(
                    Collectors.toMap(oEmp -> oEmp.getEmail().toLowerCase(Locale.ROOT), oEmp -> oEmp.getDOB()));

            // fetching Emp corp details of emp which are already present.
            Optional<List<EmployeeCorpDetails>> employeeOptional =
                    employeeRepository.findByEmail(new ArrayList<>(origEmpEmailDobMap.keySet()));

            //fetch all email and ID we got from MIS3.0 emp corp table
            Map<String, Integer> empCorpEmailIdMap = employeeOptional.get().stream().collect(
                    Collectors.toMap(corpDetails -> corpDetails.getEmail().toLowerCase(Locale.ROOT),
                            corpDetails -> corpDetails.getEmployeeId()));

            origEmpEmailDobMap.keySet().stream().forEach(e -> {
                String dob = origEmpEmailDobMap.get(e);
                DateTimeFormatter format = DateTimeFormatter.ofPattern("M/dd/yyyy");
                LocalDate empDOB = LocalDate.parse(dob, format);

                //Checking if email we get from original MIS api is present in emp corp table of MIS 3.0
                if (empCorpEmailIdMap.containsKey(e)) {
                    if (empPersonalDtMap.containsKey(empCorpEmailIdMap.get(e))) {
                        // Checking if DOB present in our(MIS3.0) emp personal detail table is same as provided in original MIS api data.
                        // If not update with correct data.
                        //log.info("Email present in empCorpDetails. Email : {}", e);
                        int id = empCorpEmailIdMap.get(e);
                        if (!empPersonalDtMap.get(id).getEmpDOB().equals(empDOB)) {
                            empPersonalDtMap.get(id).setEmpDOB(empDOB);
                            empPersonalRepository.save(empPersonalDtMap.get(id));
                            log.info("updated DOB for emp with email : {}", e);
                        }
                    } else {
                        log.info(
                                "Email not present in emp personal details table . Adding details for emp with email : {}",
                                e);
                        // This will be new emp added. saving the details for the same.
                        EmployeePersonalDetails employeePersonalDetails = new EmployeePersonalDetails();
                        employeePersonalDetails.setEmpId(empCorpEmailIdMap.get(e));
                        employeePersonalDetails.setEmpDOB(empDOB);
                        empPersonalRepository.save(employeePersonalDetails);
                    }
                } else {
                    log.error("Employee details not added in emp corp details. Please add the details.");
                }
            });
        } catch (Exception e) {
            log.error("Error updating emp personal details: {}", e.getMessage());
        }
        log.info("Add/ Update Emp Personal details : completed");
    }

    /**
     * To check if the employee has left or not!
     *
     * @param origEmpList
     */
    private void checkEmpIsActive(final List<MISEmpDetails> origEmpList) {
        log.info("Checking if emp is active or not.");
        List<String> origEmpEmailList =
                origEmpList.stream()
                           .map(e -> e.getEmail().toLowerCase(Locale.ROOT))
                           .collect(Collectors.toList());

        allEmployee = employeeRepository.findAll();
        allEmployee.parallelStream().forEach(emp -> {
            boolean checkFlag = true;
            if (origEmpEmailList.contains(emp.getEmail())) {
                checkFlag = false;
            }
            if (checkFlag) {
                if (emp.getIsActiveEmployee()) {
                    emp.setIsActiveEmployee(false);
                    employeeRepository.save(emp);
                    // removing Emp in allEmpCorpDetails list if present.
                    if (allEmpCorpDetails.contains(emp)) {
                        allEmpCorpDetails.remove(emp);
                    }
                    log.info("emp with id - " + emp.getEmail() + " set to inactive.");
                }
            } else {
                if (!emp.getIsActiveEmployee()) {
                    emp.setIsActiveEmployee(true);
                    employeeRepository.save(emp);
                    // Adding Emp in allEmpCorpDetails list if it's not present.
                    if (!allEmpCorpDetails.contains(emp)) {
                        allEmpCorpDetails.add(emp);
                    }
                    log.info("emp with id - " + emp.getEmail() + " set to active.");
                }
            }
        });
        log.info("Checking if emp is active or not : Completed");
    }


    /**
     * method to return the List of EmployeeCorpDetails objects
     *
     * @return
     */


    public List<EmployeeCorpDetails> getAllEmpCorpDetails() {
        return new ArrayList<>(allEmpCorpDetails);
    }

    /**
     * method to return S3 client to access S3 bucket
     *
     * @return S3Client
     */

    private S3Client getS3Client() {
        AwsBasicCredentials awsCreds = AwsBasicCredentials.create(accessKey, secretKey);
        S3Client client = S3Client.builder().credentialsProvider(StaticCredentialsProvider.create(awsCreds))
                                  .region(Region.AP_SOUTH_1).build();
        return client;
    }


    /**
     * method to store Profile Images of Employee to S3 Bucket
     * and return the url of S3 bucket
     *
     * @param imageURL1
     * @param email1
     *
     * @return
     */
    public String storeImagesToS3Bucket(
            final String imageURL1, final String email1
    ) {
        if (awsActive) {
            String imageURL = "";
            if (imageURL1.charAt(4) == 's') {
                imageURL = imageURL + imageURL1;
            } else {
                imageURL = imageURL + "https" + imageURL1.substring(4);
            }
            String email = "";
            email = email + email1.substring(0, email1.length() - 4);
            String encryptedEmail;
            encryptedEmail = imagePrefix + encrypter.encrypt(email) + ".png";

            try {
                URL url = new URL(imageURL);
                InputStream is = null;
                is = url.openStream();
                byte[] imageBytes = IOUtils.toByteArray(is);
                InputStream targetStream = new ByteArrayInputStream(imageBytes);

                S3Client client = getS3Client();
                PutObjectRequest request = PutObjectRequest.builder()
                                                           .bucket(bucket)
                                                           .key(encryptedEmail)
                                                           .acl("public-read")
                                                           .build();
                client.putObject(request,
                        RequestBody.fromInputStream(targetStream, targetStream.available()));
                URL s3Url = amazonS3Client.getUrl(bucket, encryptedEmail);
                String urlS3 = s3Url.toExternalForm();
                is.close();
                client.close();
                targetStream.close();
                log.info("User image successfully added to S3 bucket : " + email);
                return urlS3;
            } catch (IOException e) {
                log.error("Exception while storing image to S3 bucket : {}", e.getMessage());
                return null;
            }
        } else {
            return null;
        }
    }

    /**
     * loads all profile image keys of S3 in a Set
     */
    private void loadAllImageFromBucket() {
        try {
            ListObjectsV2Request request = new ListObjectsV2Request().withBucketName(bucket);
            request.setPrefix(imagePrefix);
            ListObjectsV2Result response;
            String continuationToken = null;
            do {
                if (continuationToken != null) {
                    request.setContinuationToken(continuationToken);
                }
                response = amazonS3Client.listObjectsV2(request);
                response.getObjectSummaries().forEach(objSummary -> {
                    profileImageHashSet.add(objSummary.getKey());
                });
                if (response.isTruncated()) {
                    continuationToken = response.getNextContinuationToken();
                }
            } while (response.isTruncated());
        } catch (Exception e) {
            log.error("Exception while fetching Objects from S3 bucket : {}", e.getMessage());
        }
        log.info("Total Profile Images in S3 : " + profileImageHashSet.size());
    }


    /**
     * method to delete extra profile images from S3 Bucket
     */
    public String deleteExtraProfileImagesFromS3Bucket() {
        try {
            Set<String> extraProfileImagesKeys = new HashSet<>();
            extraProfileImagesKeys.addAll(profileImageHashSet);
            employeeRepository.getAllEmails().stream().forEach(email -> {
                String encryptedMail = imagePrefix + encrypter.encrypt(email.substring(0, email.length() - 4)) + ".png";
                if (profileImageHashSet.contains(encryptedMail)) {
                    extraProfileImagesKeys.remove(encryptedMail);
                }
            });
            log.info("Total Number of Extra Profile Images in S3 : " + extraProfileImagesKeys.size());
            extraProfileImagesKeys.forEach(imageKey -> deleteS3BucketFile(imageKey));
            profileImageHashSet.removeAll(extraProfileImagesKeys);
        } catch (Exception ex) {
            log.error("Exception in deleteExtraProfileImagesFromS3Bucket : {}", ex.getMessage());
            return "Unable to remove extra profile images from S3";
        }
        return "Successfully removed extra profile images from S3";
    }

    /**
     * method to delete files by name from S3 Bucket
     *
     * @param keyName
     */
    private void deleteS3BucketFile(final String keyName) {
        if (!existS3Object(keyName)) {
            log.info("S3 Bucket doesn't contain object");
            return;
        }
        final DeleteObjectRequest deleteObjectRequest = new DeleteObjectRequest(bucket, keyName);
        try {
            amazonS3Client.deleteObject(deleteObjectRequest);
        } catch (Exception e) {
            log.error("Exception in S3 file deleting : {}", e.getMessage());
        }
        log.info("File deleted successfully.");
    }

    /**
     * method to check whether file exists on S3 Bucket by name
     *
     * @param name
     *
     * @return
     */
    private boolean existS3Object(final String name) {
        try {
            amazonS3Client.getObjectMetadata(bucket, name);
        } catch (AmazonServiceException e) {
            return false;
        }
        return true;
    }
}

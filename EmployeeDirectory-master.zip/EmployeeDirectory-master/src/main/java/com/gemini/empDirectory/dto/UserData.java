package com.gemini.empDirectory.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UserData {
    //private int employeeId;
    private Integer empId;
    private String Email;
    private String EmployeeCode;
    private String EmployeeName;
    private String Designation;
    private String DepartmentName;
    private String ExtensionNo;
    private String WorkStationNo;
    private String MobileNo;
    private String ImagePath;
    private String Team;
    private String Location;
    private String ReportingManager;

    public UserData(final Integer empId, final String email, final String employeeCode, final String employeeName, final String designation, final String departmentName, final String extensionNo, final String workStationNo,
                    final String mobileNo, final String imagePath, final String team, final String location, final String reportingManager) {
        this.empId = empId;
        Email = email;
        EmployeeCode = employeeCode;
        EmployeeName = employeeName;
        Designation = designation;
        DepartmentName = departmentName;
        ExtensionNo = extensionNo;
        WorkStationNo = workStationNo;
        MobileNo = mobileNo;
        ImagePath = imagePath;
        Team = team;
        Location = location;
        ReportingManager = reportingManager;
    }
}


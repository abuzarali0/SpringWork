package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.model.Designation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface DesignationRepo extends JpaRepository<Designation, Integer> {

    //Designation findByDesignationName(String designationName);
    @Query(nativeQuery = true,
    value = "select * from gemini_designation where designation_name=?1")
    Designation getDesignationName(String name);

    @Query(nativeQuery = true,
    value = "select designation_name from gemini_designation")
    Set<String> getAllDesignation();

    @Query(nativeQuery = true,
            value = "select * from gemini_designation where designation_id IN (:desigIds)")
    List<Designation> findAllByIds(List<Integer> desigIds);

    @Override
    @Query(nativeQuery = true,
            value = "select * from gemini_designation")
    List<Designation> findAll();
}

package com.gemini.empDirectory.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class NewJoinersDTO {

    private Integer employeeId;

    private String email;

    private LocalDate dateOfJoining;

    private String employeeName;

    private String profileImagePath;

    public NewJoinersDTO(
            final Integer employeeId, final String email, final LocalDate dateOfJoining, final String employeeName,
            final String profileImagePath
    ) {
        this.employeeId = employeeId;
        this.email = email;
        this.dateOfJoining = dateOfJoining;
        this.employeeName = employeeName;
        this.profileImagePath = profileImagePath;
    }
}

package com.gemini.empDirectory.service.datafetcher;

import com.gemini.empDirectory.model.EmployeeCorpDetails;
import com.gemini.empDirectory.repository.TeamRepo;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TeamResolverFetcher {
    @Autowired
    private TeamRepo teamRepo;

    /**
     * Get Team of the employee
     * @return
     */
    public DataFetcher getTeam() {
        return dataFetchingEnvironment -> {
            EmployeeCorpDetails employeeCorpDetails = dataFetchingEnvironment.getSource();
            return teamRepo.findById(employeeCorpDetails.getTeamId());
        };
    }
}

package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.model.EmployeeLastJobDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EmployeeLastJobDetailsRepository extends JpaRepository<EmployeeLastJobDetails, Integer> {
    @Query(
            value = "select * from employee_last_job_details where emp_id = ?1", nativeQuery = true
    )
    Optional<EmployeeLastJobDetails> findByEmpId(int empId);
}

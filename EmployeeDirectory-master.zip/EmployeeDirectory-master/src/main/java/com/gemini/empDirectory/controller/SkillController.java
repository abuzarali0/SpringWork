package com.gemini.empDirectory.controller;

import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.EmployeeSkills;
import com.gemini.empDirectory.service.EmployeeService;
import com.gemini.empDirectory.service.SkillService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(value = "/employee-skills")
@Tag(
        name = "Employee Skills",
        description = "operations related to Employee Skills in EMS"
)
@Api(tags = { "Employee Skills" })
public class SkillController {

    @Autowired
    private SkillService skillService;

    @Autowired
    private EmployeeService employeeService;

    /**
     *
     * @param empId
     * @return
     */

    @ApiOperation(
            value = "view Employee skill Details by Employee ID",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully retrieved resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping
    public ResponseEntity<ResponseApi> getSkillByEmpId(
            @ApiParam(
                    name = "empId",
                    type = "Integer",
                    value = "ID of Employee",
                    example = "1"
            ) final @RequestParam(value = "empId") int empId
    ) {
        if (employeeService.findById(empId) == null) {
            ResponseApi response = new ResponseApi(
                    HttpStatus.BAD_REQUEST,
                    "Employee Id doesn't exist"
            );
            return ResponseEntity.status(response.getStatus()).body(response);
        }
        ResponseApi response = skillService.getSkillByEmpId(empId);
        log.info(
                "ResponseMessage for getSkillByEmpId() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     *
     * @param skill
     * @param empId
     * @return
     */

    @ApiOperation(
            value = "add Employee skill Details by Employee ID",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully added resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to add the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to add is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to add is not found"
                    ),
            }
    )
    @PostMapping
    public ResponseEntity<ResponseApi> addSkillByEmpId(
            @ApiParam(
                    name = "Employee Skills",
                    value = "Skills of the Employee"
            ) final @RequestBody EmployeeSkills skill,
            @ApiParam(
                    name = "empId",
                    type = "Integer",
                    value = "ID of Employee",
                    example = "1"
            ) final @RequestParam(value = "empId") int empId
    ) {
        if (employeeService.findById(empId) == null) {
            ResponseApi response = new ResponseApi(
                    HttpStatus.BAD_REQUEST,
                    "Employee Id doesn't exist"
            );
            return ResponseEntity.status(response.getStatus()).body(response);
        }
        ResponseApi response = skillService.addSkill(skill, empId);
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     *
     * @param skillId
     * @return
     */

    @ApiOperation(
            value = "delete Employee skill details by skill ID",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully deleted resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to delete the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to delete is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to delete is not found"
                    ),
            }
    )
    @DeleteMapping
    public ResponseEntity<ResponseApi> deleteSkillById(
            @ApiParam(
                    name = "skillId",
                    type = "Integer",
                    value = "Skill ID of Employee",
                    example = "1"
            ) final @RequestParam(value = "skillId") int skillId
    ) {
        ResponseApi response = skillService.deleteSkillById(skillId);
        log.info(
                "ResponseMessage for deleteSkillById() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }
}

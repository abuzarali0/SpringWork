package com.gemini.empDirectory.service.datafetcher;

import com.gemini.empDirectory.model.EmployeeCorpDetails;
import com.gemini.empDirectory.repository.DesignationRepo;
import graphql.schema.DataFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DesignationResolverFetcher {
    @Autowired
    private DesignationRepo designationRepo;

    /**
     * get Designation for Employee
     * @return
     */
    public DataFetcher getDesignationsForEmp() {
        return dataFetchingEnvironment -> {
            EmployeeCorpDetails employeeCorpDetails = dataFetchingEnvironment.getSource();
            return designationRepo.findById(employeeCorpDetails.getDesignationId());
        };
    }
}

package com.gemini.empDirectory.repository;

import com.gemini.empDirectory.model.EmpFamilyDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FamilyDetailsRepo extends JpaRepository<EmpFamilyDetails, Integer> {

    @Query(nativeQuery = true,
        value = "select * from employee_family_details where emp_id =?"
    )
    List<EmpFamilyDetails> findByEmpId(int empId);
}

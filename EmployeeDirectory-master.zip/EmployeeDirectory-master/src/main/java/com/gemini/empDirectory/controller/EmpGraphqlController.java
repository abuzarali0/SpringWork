package com.gemini.empDirectory.controller;

import com.gemini.empDirectory.service.GraphQLService;
import graphql.ExecutionResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/employee-graph")
public class EmpGraphqlController {

    @Autowired
    private GraphQLService graphQLService;


    /**
     *
     * @param query
     * @return
     */
    @GetMapping("/employees")
    public ResponseEntity<Object> getAllEmps(@RequestParam("Query") final String query) {
        ExecutionResult execute = graphQLService.getGraphQL().execute(query);
        return new ResponseEntity<>(execute, HttpStatus.OK);
    }

    /**
     *
     * @param query
     * @return
     */
    @PostMapping("/designations")
    public ResponseEntity<Object> getAllDesignations(@RequestBody final String query) {
        ExecutionResult execute = graphQLService.getGraphQL().execute(query);
        return new ResponseEntity<>(execute, HttpStatus.OK);
    }

    /**
     *
     * @param query
     * @return
     */
    @PostMapping("/user")
    public ResponseEntity<Object> getEmployeeDirectory(@RequestBody final String query) {
        ExecutionResult execute = graphQLService.getGraphQL().execute(query);
        return new ResponseEntity<>(execute, HttpStatus.OK);
    }

    /**
     *
     * @param query
     * @return
     */
    @PostMapping("/departments")
    public ResponseEntity<Object> getAllDepartments(@RequestBody final String query) {
        ExecutionResult execute = graphQLService.getGraphQL().execute(query);
        return new ResponseEntity<>(execute, HttpStatus.OK);
    }

    /**
     *
     * @param query
     * @return
     */
    @PostMapping("/teams")
    public ResponseEntity<Object> getAllTeams(@RequestBody final String query) {
        ExecutionResult execute = graphQLService.getGraphQL().execute(query);
        return new ResponseEntity<>(execute, HttpStatus.OK);
    }
}

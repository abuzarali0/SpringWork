package com.gemini.empDirectory.service;

import com.gemini.empDirectory.dto.ResponseApi;
import com.gemini.empDirectory.model.EmployeeCorpDetails;
import com.gemini.empDirectory.model.EmployeePersonalDetails;
import com.gemini.empDirectory.repository.EmployeePersonalDetailsRepository;
import com.gemini.empDirectory.repository.EmployeeRepository;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class EmployeePersonalDetailsService {

    @Autowired
    private EmployeePersonalDetailsRepository repository;

    @Autowired
    private EmployeeRepository employeeRepository;

    /**
     * Service method to fetch the personal details of employee
     * @param empId
     * @return
     */
    public ResponseApi getPersonalDetails(
            final Integer empId,
            final Integer empPersonalDetailId
    ) {
        try {
            Optional<EmployeePersonalDetails> employeePersonalDetails = null;
            if (empId != null) {
                employeePersonalDetails = repository.findByEmployeeId(empId);
                if (employeePersonalDetails.isEmpty()) {
                    return new ResponseApi(
                            HttpStatus.NOT_FOUND,
                            "employee Id~ " + empId + " not found"
                    );
                }
            } else if (empPersonalDetailId != null) {
                employeePersonalDetails = repository.findById(empPersonalDetailId);
                if (employeePersonalDetails.isEmpty()) {
                    return new ResponseApi(
                            HttpStatus.NOT_FOUND,
                            "employee personal detail id" + empPersonalDetailId + " not found"
                    );
                }
            } else {
                return new ResponseApi(
                        HttpStatus.BAD_REQUEST,
                        "Send a  valid request. No personal details Id or empId is present!"
                );
            }
            return new ResponseApi(HttpStatus.OK, employeePersonalDetails.get());
        } catch (Exception e) {
            log.error("Exception in getPersonalDetails() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to get the personal details of employee(s)"
            );
        }
    }

    /**
     * Service method to save the personal details of the employee
     * @param dto
     * @param empId
     * @return
     */
    public ResponseApi savePersonalDetails(
            final EmployeePersonalDetails dto,
            final Integer empId
    ) {
        try {
            Optional<EmployeeCorpDetails> optional = employeeRepository.findById(
                    empId
            );
            if (optional.isEmpty()) {
                return new ResponseApi(
                        HttpStatus.NOT_FOUND,
                        "employee Id~ " + empId + " not found"
                );
            }

            EmployeePersonalDetails personalDetails = new EmployeePersonalDetails(
                    dto.getPersonalEmail(),
                    dto.getEmpDOB(),
                    dto.getBloodGroup(),
                    dto.getGender(),
                    dto.getMaritalStatus(),
                    dto.getPanCardId(),
                    dto.getAadhaarCardId(),
                    dto.getVoterCardId(),
                    dto.getDrivingLicenseId(),
                    dto.getPassportId()
            );
            repository.save(personalDetails);
            return new ResponseApi(
                    HttpStatus.OK,
                    "Personal details saved successfully!"
            );
        } catch (Exception e) {
            log.error("Exception in savePersonalDetails() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to save the personal details of employee(s)"
            );
        }
    }

    /**
     * Service method to update the personal details
     * @param dto
     * @param personalDetailsId
     * @return
     */
    public ResponseApi updatePersonalDetails(
            final EmployeePersonalDetails dto,
            final Integer personalDetailsId
    ) {
        try {
            Optional<EmployeePersonalDetails> optional = repository.findById(
                    personalDetailsId
            );
            if (optional.isEmpty()) {
                return new ResponseApi(
                        HttpStatus.NOT_FOUND,
                        "personalDetails Id~ " + personalDetailsId + " not found"
                );
            }
            EmployeePersonalDetails personalDetails = new EmployeePersonalDetails(
                    dto.getPersonalEmail(),
                    dto.getEmpDOB(),
                    dto.getBloodGroup(),
                    dto.getGender(),
                    dto.getMaritalStatus(),
                    dto.getPanCardId(),
                    dto.getAadhaarCardId(),
                    dto.getVoterCardId(),
                    dto.getDrivingLicenseId(),
                    dto.getPassportId()
            );
            personalDetails.setEmployeePersonalDetailId(
                    optional.get().getEmployeePersonalDetailId()
            );
            repository.save(personalDetails);
            return new ResponseApi(
                    HttpStatus.OK,
                    "Personal details updated successfully!"
            );
        } catch (Exception e) {
            log.error("Exception in updatePersonalDetails() : {}", e.getMessage());
            return new ResponseApi(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update the personal details of employee(s)"
            );
        }
    }
}

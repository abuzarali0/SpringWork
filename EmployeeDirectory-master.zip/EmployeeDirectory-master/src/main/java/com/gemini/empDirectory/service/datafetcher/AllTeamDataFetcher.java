package com.gemini.empDirectory.service.datafetcher;

import com.gemini.empDirectory.model.Team;
import com.gemini.empDirectory.repository.TeamRepo;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AllTeamDataFetcher implements DataFetcher<List<Team>> {
    @Autowired
    private TeamRepo teamRepo;

    /**
     *
     * @param dataFetchingEnvironment
     * @return
     */
    @Override
    public List<Team> get(final DataFetchingEnvironment dataFetchingEnvironment) {
        return teamRepo.findAll();
    }
}

package com.gemini.empDirectory.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@Data
@Entity
@Table(name = "employee_corp_details", uniqueConstraints = {@UniqueConstraint(name = "UniqueEmpCodeAndEmail", columnNames = {"emp_code", "email"})})
//@Where(clause = "is_active_emp = true")
public class EmployeeCorpDetails {

    @Id
    @Column(name = "emp_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(hidden = true)
    private Integer employeeId;

    @Column(name = "emp_code", length = 15)
    @ApiModelProperty(notes = "Employee Code")
    private String employeeCode;

    @Column(name = "email", length = 50)
    @ApiModelProperty(notes = "official email Id of employee")
    private String email;

    @Column(name = "employee_name")
    @ApiModelProperty(notes = "name of the employee")
    private String employeeName;

    @ApiModelProperty(hidden = true)
    @Column(name = "designation_id")
    private int designationId;

    @ApiModelProperty(hidden = true)
    @Column(name = "team_id")
    private int teamId;

    @Column(name = "contact_no", length = 10)
    @ApiModelProperty(notes = "Employee Contact Number")
    private String contactNo;

    @Column(name = "emergency_contact_no", length = 10)
    @ApiModelProperty(notes = "emergency contact number of employee")
    private String emergencyContactNo;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @ApiModelProperty(notes = "Date of joining")
    @Column(name = "date_of_joining")
    private LocalDate dateOfJoining;

    @Column(name = "extension_no")
    @ApiModelProperty(notes = "extension Number")
    private String extensionNo;

    @Column(name = "work_station_no")
    @ApiModelProperty(notes = "work station number")
    private String workStationNo; //WsNo

    @Column(name = "office_location")
    @ApiModelProperty(notes = "office location ")
    private String officeLocation;

    @Column(name = "reporting_manager")
    @ApiModelProperty(notes = "employee reporting manager email")
    private String reportingManager;

    @Column(name = "image_path")
    @ApiModelProperty(notes = "path of the image")
    private String profileImagePath;

    @Column(name = "image_s3_path")
    @ApiModelProperty(notes = "name of image file s3 bucket")
    private String profileImageS3Path;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Column(name = "termination_date")
    @ApiModelProperty(notes = "termination date")
    private LocalDate terminationDate;

    @Column(name = "is_fresher")
    @ApiModelProperty(notes = "whether employee is fresher or not")
    private boolean isFresher;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Column(name = "FTE_date")
    @ApiModelProperty(notes = "FTE date")
    private LocalDate FTEDate;

    @Column(name = "probation_period_months")
    private int probationPeriodInMonths;

    @Column(name = "is_active_emp")
    private Boolean isActiveEmployee = true;

    //To be stored in the appraisal section
//    @Column(name = "last_promotion_designation")
//    private String LastPromotionDesignation;

    //PimcoUser Table
/*
    Will try to adjust these in the project management module under Pimco hood

    @Column(name = "is_pimco_user")
    private boolean IsPimcoUser;

    @Column(name = "pimco_user_id")
    private String PimcoUserId;

    @Column(name = "pimco_manager")
    private String PimcoManager;


    To be stored in the Access card management service
    //UserAccessCard and AccessCard

    @Column(name = "access_card_Id")
    private String EmpAccessCardId;  //card number

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Column(name = "access_card_assignedDate")
    private LocalDate AccessCardAssignedDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Column(name = "access_card_assignedTillDate")
    private LocalDate CardAssignedTillDate;

    //    // why is punch id required?
//    @Column(name = "punch_id")
//    private String EmpPunchId;
     */

    public EmployeeCorpDetails(final String employeeCode, final String email, final String employeeName, final String contactNo, final String extensionNo, final String workStationNo,
                               final String location, final String reportingManager, final String profileImagePath) {
        this.employeeCode = employeeCode;
        this.email = email;
        this.employeeName = employeeName;
        this.contactNo = contactNo;
        this.extensionNo = extensionNo;
        this.workStationNo = workStationNo;
        officeLocation = location;
        this.reportingManager = reportingManager;
        this.profileImagePath = profileImagePath;
    }

    public EmployeeCorpDetails(final String employeeCode, final String email, final String employeeName, final String contactNo, final String extensionNo, final String workStationNo,
                               final String location, final String reportingManager, final String profileImagePath, final LocalDate joiningDate, final boolean isFresher,
                               final String profileImageS3Path) {
        this.employeeCode = employeeCode;
        this.email = email;
        this.employeeName = employeeName;
        this.contactNo = contactNo;
        this.extensionNo = extensionNo;
        this.workStationNo = workStationNo;
        officeLocation = location;
        this.reportingManager = reportingManager;
        this.profileImagePath = profileImagePath;
        this.dateOfJoining = joiningDate;
        this.isFresher = isFresher;
        this.profileImageS3Path = profileImageS3Path;
    }
}

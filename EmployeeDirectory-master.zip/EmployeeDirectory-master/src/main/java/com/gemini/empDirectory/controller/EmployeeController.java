package com.gemini.empDirectory.controller;

import com.gemini.empDirectory.dto.*;
import com.gemini.empDirectory.model.EmployeeCorpDetails;
import com.gemini.empDirectory.repository.EmployeeRepository;
import com.gemini.empDirectory.service.EmployeeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping(value = "/employee-directory")
@Tag(
        name = "Employee Details",
        description = "operations related to Employee details in EMS"
)
@Api(tags = {"Employee Details"})
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private EmployeeRepository repository;

    /**
     * @return
     */

    @ApiOperation(
            value = "view  set of employee details by the page number",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully retrieved resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping("/paginated-users")
    public ResponseEntity<ResponseApi> getPaginatedEmployeeDetails(
            @ApiParam(
                    name = "pageNum",
                    value = "Page Number you want to retrieve data from",
                    example = "1"
            ) final @RequestParam("pageNum") int pageNumber
    ) {
        if (pageNumber < 0) {
            ResponseApi response = new ResponseApi(
                    HttpStatus.BAD_REQUEST,
                    "PageNumber cannot be negative"
            );
            return ResponseEntity.status(response.getStatus()).body(response);
        }
        ResponseApi response = employeeService.getPaginatedEmployeeDetails(
                pageNumber
        );
        log.info(
                "ResponseMessage for getAllEmployeeDetails() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     * @return
     */

    @ApiOperation(
            value = "view all Employee Details",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully retrieved resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping("/users")
    public ResponseEntity<ResponseApi> getAllEmployeeDetails() {
        ResponseApi response = employeeService.getEmployeeDetails();
        log.info(
                "ResponseMessage for getAllEmployeeDetails() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     * api to get upcoming Work Anniversary List
     *
     * @return
     */
    @ApiOperation(value = "get anniversary list", response = ResponseApi.class)
    @ApiResponses(
            value = {
                    @ApiResponse(
                            code = 200,
                            message = "Successfully fetched upcoming anniversaries"
                    ),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping("anniversaries")
    public ResponseEntity<ResponseApi> getAnniversaryList() {
        ResponseApi response = employeeService.getAllWorkAnniversaryList();
        log.info("ResponseMessage for getAnniversaryList() is : {}", response.getMessage());
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     * api to get upcoming Birthdays List
     *
     * @return
     */
    @ApiOperation(value = "get birthday list", response = ResponseApi.class)
    @ApiResponses(
            value = {
                    @ApiResponse(
                            code = 200,
                            message = "Successfully fetched upcoming birthdays"
                    ),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping("/birthdays")
    public ResponseEntity<ResponseApi> getBirthdayList() {
        ResponseApi response = employeeService.getAllBirthdayList();
        log.info("ResponseMessage for getBirthdayList() is : {}", response.getMessage());
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     * api to get upcoming new Joiners List
     *
     * @return
     */

    @ApiOperation(value = "get new Joiners list", response = ResponseApi.class)
    @ApiResponses(
            value = {
                    @ApiResponse(
                            code = 200,
                            message = "Successfully fetched upcoming new Joiners"
                    ),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping("/new-joiners")
    public ResponseEntity<ResponseApi> getNewJoinerList() {
        ResponseApi response;
        try {
            List<NewJoinersDTO> newJoinersDTOList = employeeService.getAllNewJoinersList();
            response = new ResponseApi(HttpStatus.OK, newJoinersDTOList);
        } catch (Exception e) {
            log.error("Exception in getNewJoinerList() : {}", e.getMessage());
            response = new ResponseApi(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to fetch new joiners");
        }
        log.info(
                "ResponseMessage for getNewJoinerList() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     * @return
     */

    @ApiOperation(
            value = "view Employee objects list which is used in other services",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully retrieved resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping("/employees-list")
    public ResponseEntity<ResponseApi> getEmployeeObjectsList() {
        ResponseApi response = employeeService.getEmployeesObjectsList();
        log.info(
                "ResponseMessage for getEmployeeObjectsList() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     * @param userId
     * @return
     */

    @ApiOperation(
            value = "view Employee details by Employee ID",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully retrieved resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @GetMapping("/user/{userId}")
    public ResponseEntity<ResponseApi> getDetailsByEmpId(
            @ApiParam(
                    name = "userId",
                    value = "ID of the Employee",
                    example = "1"
            ) final @PathVariable int userId
    ) {
        ResponseApi response = employeeService.getDetailsById(userId);
        log.info(
                "ResponseMessage for getDetailsByEmpId() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

  /*
    *@DeleteMapping
    public ResponseEntity<ApiResponse> deleteEmpDetails(@RequestParam(value = "empId") int empId){
        ApiResponse response=employeeService.deleteEmpDetails(empId);
        log.info("ResponseMessage for deleteEmpDetails() is : {}",response.getMessage());
        return ResponseEntity.status(response.getStatus()).body(response);
    }

     */

    /**
     * @param empId
     * @param EmpDetails
     * @return
     */

    @ApiOperation(
            value = "update Employee details by Employee ID",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully updated resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to update the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to update is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to update is not found"
                    ),
            }
    )
    @PutMapping("/user")
    public ResponseEntity<ResponseApi> updateEmpDetails(
            @ApiParam(
                    name = "empId",
                    type = "Integer",
                    value = "ID of Employee",
                    example = "1"
            ) final @RequestParam(value = "empId") int empId,
            @ApiParam(
                    name = "Employee Details",
                    value = "Details of the Employee to be updated "
            ) final @RequestBody UpdateEmpDetails EmpDetails
    ) {
        ResponseApi response = employeeService.updateEmpDetails(empId, EmpDetails);
        log.info(
                "ResponseMessage for updateEmpDetails() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     * @param details
     * @param designationId
     * @param teamId
     * @return
     */

    @ApiOperation(value = "add Employee details", response = ResponseApi.class)
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully added resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to add the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to add is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to add is not found"
                    ),
            }
    )
    @PostMapping("/user")
    public ResponseEntity<ResponseApi> addEmployeeDetails(
            @ApiParam(
                    name = "Employee Details",
                    value = "new employee details to be added"
            ) final @RequestBody EmployeeCorpDetails details,
            @ApiParam(
                    name = "designationId",
                    value = "Employee designation id",
                    example = "1"
            ) final @RequestParam(value = "designationId") int designationId,
            @ApiParam(
                    name = "teamId",
                    value = "Employee Team id",
                    example = "1"
            ) final @RequestParam(value = "teamId") int teamId
    ) {
        ResponseApi response = employeeService.addEmpDetails(
                details,
                designationId,
                teamId
        );
        log.info(
                "ResponseMessage for addEmpDetails() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     * @param lEmail
     * @return
     */

    @ApiOperation(
            value = "view employee details by employee email id",
            response = ResponseApi.class
    )
    @ApiResponses(
            value = {
                    @ApiResponse(code = 200, message = "Successfully retrieved resource"),
                    @ApiResponse(
                            code = 401,
                            message = "You are not authorized to view the resource"
                    ),
                    @ApiResponse(
                            code = 403,
                            message = "Accessing the resource you were trying to reach is forbidden"
                    ),
                    @ApiResponse(
                            code = 404,
                            message = "The resource you were trying to reach is not found"
                    ),
            }
    )
    @PostMapping("/user-by-email")
    public ResponseEntity<ResponseApi> getUserData(
            @ApiParam(
                    name = "email",
                    value = "email id of Employee"
            ) final @RequestBody List<String> lEmail
    ) {
        ResponseApi response = employeeService.getUserDataByEmail(lEmail);
        log.info(
                "ResponseMessage for getUserData() is : {}",
                response.getMessage()
        );
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    /**
     * API operation to retrieve the data for the organization structure
     *
     * @return
     */
    @ApiOperation(value = "view employee details by employee email id", response = ResponseApi.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved resource"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    })
    @GetMapping("/organization-hierarchy")
    public ResponseEntity<ResponseApi> getOrganizationStructure() {
        ResponseApi responseApi = employeeService.getOrganizationData();
        log.info("ResponseMessage for getOrganizationStructure() is : {}", responseApi.getMessage());
        return ResponseEntity.status(responseApi.getStatus()).body(responseApi);
    }

    /**
     * API operation to delete the extra profile images stored in S3
     *
     * @return
     */

    @GetMapping("/delete-extra-profile-image")
    public ResponseEntity<ResponseApi> deleteExtraProfileImagesInS3() {
        ResponseApi responseApi = employeeService.deleteExtraProfileImagesInS3();
        log.info("ResponseMessage for deleteExtraProfileImagesInS3() is : {}", responseApi.getMessage());
        return ResponseEntity.status(responseApi.getStatus()).body(responseApi);
    }

}

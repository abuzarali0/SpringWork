package com.gemini.empDirectory.enums;

public enum MaritalStatus {
    SINGLE,
    MARRIED,
    WIDOWED,
    DIVORCED
}

/*
package com.gemini.empDirectory.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AddReferralDetails {

    private String refereeName;
    private String relationWithReferee;
    private int referredById;
}
*/

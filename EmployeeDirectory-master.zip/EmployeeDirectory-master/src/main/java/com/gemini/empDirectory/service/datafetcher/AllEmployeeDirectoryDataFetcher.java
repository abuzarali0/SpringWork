package com.gemini.empDirectory.service.datafetcher;

import com.gemini.empDirectory.model.EmployeeDirectory;
import com.gemini.empDirectory.repository.EmployeeDirectoryRepo;
import graphql.schema.DataFetcher;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AllEmployeeDirectoryDataFetcher implements DataFetcher<List<EmployeeDirectory>> {
    @Autowired
    private EmployeeDirectoryRepo repo;

    /**
     *
     * @param dataFetchingEnvironment
     * @return
     */
    @Override
    public List<EmployeeDirectory> get(final DataFetchingEnvironment dataFetchingEnvironment) {
        return repo.findAll();
    }
}

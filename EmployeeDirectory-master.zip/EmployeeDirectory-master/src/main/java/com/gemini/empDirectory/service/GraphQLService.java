package com.gemini.empDirectory.service;

import com.gemini.empDirectory.service.datafetcher.*;
import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import graphql.GraphQL;
import graphql.schema.GraphQLSchema;
import graphql.schema.idl.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.net.URL;

@Service
public class GraphQLService {

    @Value("empDir.graphql")
    private String graphQlSchema;

    private GraphQL graphQL;
    @Autowired
    private AllEmpsDataFetcher allEmpsDataFetcher;
    @Autowired
    private EmpDataFetcher empDataFetcher;
    @Autowired
    private AllDesgnationsDataFetcher allDesgnationsDataFetcher;
    @Autowired
    private DesignationDataFetcher designationDataFetcher;
    @Autowired
    private AllDepartmentsDataFetcher allDepartmentsDataFetcher;
    @Autowired
    private DepartmentDataFetcher departmentDataFetcher;
    @Autowired
    private AllTeamDataFetcher allTeamDataFetcher;
    @Autowired
    private TeamDataFetcher teamDataFetcher;
    @Autowired
    private TeamResolverFetcher teamResolverFetcher;
    @Autowired
    private DesignationResolverFetcher designationResolverFetcher;
    @Autowired
    private DepartmentResolverFetcher departmentResolverFetcher;
    @Autowired
    private AllEmployeeDirectoryDataFetcher allEmployeeDirectoryDataFetcher;

    /**
     * load schema at application start up
     *
     * @throws IOException
     */
    @PostConstruct
    private void loadSchema() throws IOException {
        // get the schema
        URL url = Resources.getResource(graphQlSchema);
        String sdl = Resources.toString(url, Charsets.UTF_8);
        // parse schema
        TypeDefinitionRegistry typeRegistry = new SchemaParser().parse(sdl);
        RuntimeWiring wiring = buildRuntimeWiring();
        GraphQLSchema graphQLSchema = new SchemaGenerator().makeExecutableSchema(typeRegistry, wiring);
        graphQL = GraphQL.newGraphQL(graphQLSchema).build();
    }


    /**
     *
     * @return
     */
    private RuntimeWiring buildRuntimeWiring() {
        return RuntimeWiring.newRuntimeWiring()
                .type("Query", typeWiring -> typeWiring
                    .dataFetcher("employees", allEmpsDataFetcher)
                    .dataFetcher("employee", empDataFetcher)
                    .dataFetcher("designations", allDesgnationsDataFetcher)
                    .dataFetcher("designation", designationDataFetcher)
                    .dataFetcher("departments", allDepartmentsDataFetcher)
                    .dataFetcher("department", departmentDataFetcher)
                    .dataFetcher("teams", allTeamDataFetcher)
                    .dataFetcher("team", teamDataFetcher)
                    .dataFetcher("employeeDirectory", allEmployeeDirectoryDataFetcher)
                )
                .type(TypeRuntimeWiring.newTypeWiring("Employee")
                    .dataFetcher("team", teamResolverFetcher.getTeam())
                    .dataFetcher("designation", designationResolverFetcher.getDesignationsForEmp())
                )
                .type(TypeRuntimeWiring.newTypeWiring("Team")
                    .dataFetcher("department", departmentResolverFetcher.getDepartmentForTeam())
                )
                .build();
    }


    /**
     *
     * @return
     */
    public GraphQL getGraphQL() {
        return graphQL;
    }
}
